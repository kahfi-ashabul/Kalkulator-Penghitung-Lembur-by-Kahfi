import { OvertimeEntry } from '../types/overtime';
import { calculateOvertime } from './calculations';

/**
 * Standard CSV Column Headers (100% synchronized with import parser)
 */
export const CSV_HEADERS = [
  'Tanggal',
  'SistemKerja',
  'JenisHari',
  'LiburResmi',
  'JamLembur',
  'UpahSebulan',
  'UpahSejam',
  'TotalLembur',
  'Catatan',
  'ID',
];

/**
 * Export entries to UTF-8 CSV with BOM for seamless Excel/Google Sheets opening
 */
export function exportToCSV(entries: OvertimeEntry[], filenamePrefix = 'riwayat-lembur-kahfi'): void {
  const rows = entries.map((e) => [
    e.tanggal,
    e.sistem, // '5_hari' | '6_hari'
    e.jenisHari, // 'biasa' | 'sabtu' | 'minggu'
    e.libur ? 'TRUE' : 'FALSE',
    e.jamLembur.toString(),
    Math.round(e.upahSebulan).toString(),
    Math.round(e.upahSejam).toString(),
    Math.round(e.totalLembur).toString(),
    `"${(e.catatan || '').replace(/"/g, '""')}"`,
    e.id,
  ]);

  // Use semicolon as default for Indonesian regional settings, with BOM so Excel recognizes UTF-8
  const csvContent = '\uFEFF' + [CSV_HEADERS.join(';'), ...rows.map((r) => r.join(';'))].join('\r\n');
  downloadBlob(csvContent, `${filenamePrefix}-${new Date().toISOString().slice(0, 10)}.csv`, 'text/csv;charset=utf-8;');
}

/**
 * Export entries to JSON backup file
 */
export function exportToJSON(entries: OvertimeEntry[], filenamePrefix = 'backup-lembur-kahfi'): void {
  const backupData = {
    versiSkema: '1.1',
    namaAplikasi: 'Kalkulator Penghitung Lembur by Kahfi',
    waktuEkspor: new Date().toISOString(),
    totalEntri: entries.length,
    entri: entries,
  };

  const jsonStr = JSON.stringify(backupData, null, 2);
  downloadBlob(jsonStr, `${filenamePrefix}-${new Date().toISOString().slice(0, 10)}.json`, 'application/json');
}

/**
 * Helper to download Blob to local disk
 */
function downloadBlob(content: string, filename: string, mimeType: string): void {
  const blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

/**
 * Generate blank template CSV for easy imports (100% matches export format)
 */
export function downloadCSVTemplate(): void {
  const sample1 = ['2026-11-08', '5_hari', 'minggu', 'FALSE', '8', '6000000', '34682', '554913', 'Lembur maintenance mingguan', 'template-01'];
  const sample2 = ['2026-11-09', '5_hari', 'biasa', 'FALSE', '3', '6000000', '34682', '190751', 'Lembur audit kepatuhan', 'template-02'];
  const sample3 = ['2026-11-14', '6_hari', 'sabtu', 'FALSE', '3', '6000000', '34682', '190751', 'Lembur 6 hari kerja Sabtu', 'template-03'];

  const content = '\uFEFF' + [CSV_HEADERS.join(';'), sample1.join(';'), sample2.join(';'), sample3.join(';')].join('\r\n');
  downloadBlob(content, 'template-import-lembur.csv', 'text/csv;charset=utf-8;');
}

/**
 * Parse imported JSON string
 */
export function parseImportJSON(jsonText: string): { validEntries: OvertimeEntry[]; errors: string[] } {
  const errors: string[] = [];
  const validEntries: OvertimeEntry[] = [];

  try {
    const parsed = JSON.parse(jsonText);
    const rawList = Array.isArray(parsed) ? parsed : parsed.entri || parsed.data;

    if (!Array.isArray(rawList)) {
      errors.push('Format JSON tidak valid: tidak ditemukan array entri.');
      return { validEntries, errors };
    }

    rawList.forEach((item: any, idx: number) => {
      const lineNum = idx + 1;
      if (!item.tanggal || typeof item.tanggal !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(item.tanggal)) {
        errors.push(`Baris ${lineNum}: Format tanggal salah (gunakan YYYY-MM-DD).`);
        return;
      }

      const sistem = item.sistem === '6_hari' ? '6_hari' : '5_hari';
      const jenisHari = ['biasa', 'sabtu', 'minggu'].includes(item.jenisHari) ? item.jenisHari : 'biasa';
      const libur = Boolean(item.libur);
      const jamLembur = Number(item.jamLembur) || 0;
      const upahSebulan = Number(item.upahSebulan) || 6000000;

      if (jamLembur <= 0) {
        errors.push(`Baris ${lineNum}: Jam lembur harus lebih dari 0.`);
        return;
      }

      // Re-calculate with pure engine for mathematical integrity
      const calc = calculateOvertime({
        gajiPokok: upahSebulan,
        tunjanganTetap: 0,
        sistem,
        jenisHari,
        liburResmi: libur,
        jamLembur,
      });

      validEntries.push({
        id: item.id || `imp-${Date.now()}-${idx}`,
        tanggal: item.tanggal,
        sistem,
        jenisHari,
        libur,
        totalJamKerja: item.totalJamKerja,
        jamLembur,
        upahSebulan: calc.upahSebulan,
        upahSejam: calc.upahSejam,
        totalLembur: calc.totalUpahLembur,
        catatan: item.catatan || '',
        dibuat: item.dibuat || new Date().toISOString(),
        breakdown: calc.breakdown,
      });
    });
  } catch (err: any) {
    errors.push(`Gagal membaca file JSON: ${err.message}`);
  }

  return { validEntries, errors };
}

/**
 * Intelligent, bi-directional CSV parser that maps columns dynamically by header name
 * or falls back gracefully to standard position.
 * 100% compatible with files exported by this app AND templates.
 */
export function parseImportCSV(csvText: string): { validEntries: OvertimeEntry[]; errors: string[] } {
  const errors: string[] = [];
  const validEntries: OvertimeEntry[] = [];

  const rawLines = csvText.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
  if (rawLines.length < 2) {
    errors.push('File CSV kosong atau hanya berisi baris judul.');
    return { validEntries, errors };
  }

  // Detect delimiter (semicolon or comma or tab)
  const firstLine = rawLines[0].replace(/^\uFEFF/, '');
  let delimiter = ';';
  if (firstLine.includes(';') && (firstLine.split(';').length >= firstLine.split(',').length)) {
    delimiter = ';';
  } else if (firstLine.includes(',')) {
    delimiter = ',';
  } else if (firstLine.includes('\t')) {
    delimiter = '\t';
  }

  // Split tokens safely respecting quoted commas/semicolons
  const parseCSVLine = (line: string): string[] => {
    const tokens: string[] = [];
    let cur = '';
    let inQuotes = false;
    for (let i = 0; i < line.length; i++) {
      const char = line[i];
      if (char === '"' || char === "'") {
        if (inQuotes && line[i + 1] === char) {
          cur += char;
          i++; // skip escaped quote
        } else {
          inQuotes = !inQuotes;
        }
      } else if (char === delimiter && !inQuotes) {
        tokens.push(cur.trim());
        cur = '';
      } else {
        cur += char;
      }
    }
    tokens.push(cur.trim());
    return tokens.map((t) => t.replace(/^["']|["']$/g, '').trim());
  };

  const headerTokens = parseCSVLine(firstLine).map((h) => h.toLowerCase().replace(/[^a-z0-9]/g, ''));

  // Map header indexes dynamically
  const colTanggal = headerTokens.findIndex((h) => h.includes('tanggal') || h.includes('date'));
  const colSistem = headerTokens.findIndex((h) => h.includes('sistem'));
  const colJenis = headerTokens.findIndex((h) => h.includes('jenishari') || h.includes('hari') || h.includes('kategori'));
  const colLibur = headerTokens.findIndex((h) => h.includes('libur'));
  const colJam = headerTokens.findIndex((h) => h.includes('jamlembur') || h === 'jam' || h.includes('durasi'));
  const colGaji = headerTokens.findIndex((h) => h.includes('upahsebulan') || h.includes('gajipokok') || h.includes('gaji') || h.includes('upah'));
  const colCatatan = headerTokens.findIndex((h) => h.includes('catatan') || h.includes('note') || h.includes('keterangan'));
  const colId = headerTokens.findIndex((h) => h === 'id' || h.includes('kode'));

  // Fallbacks if header wasn't matched
  const idxTanggal = colTanggal !== -1 ? colTanggal : 0;
  const idxSistem = colSistem !== -1 ? colSistem : 1;
  const idxJenis = colJenis !== -1 ? colJenis : 2;
  const idxLibur = colLibur !== -1 ? colLibur : 3;
  const idxJam = colJam !== -1 ? colJam : 4;
  const idxGaji = colGaji !== -1 ? colGaji : 5;
  const idxCatatan = colCatatan !== -1 ? colCatatan : 8;
  const idxId = colId !== -1 ? colId : 9;

  for (let i = 1; i < rawLines.length; i++) {
    const lineNum = i + 1;
    const parts = parseCSVLine(rawLines[i]);

    if (parts.length < 3) {
      continue; // Skip empty / malformed row
    }

    const rawTanggal = parts[idxTanggal] || '';
    if (!/^\d{4}-\d{2}-\d{2}$/.test(rawTanggal)) {
      errors.push(`Baris ${lineNum}: Format tanggal '${rawTanggal}' tidak valid (wajib YYYY-MM-DD).`);
      continue;
    }

    // Parse Sistem
    const rawSistem = (parts[idxSistem] || '').toLowerCase();
    const sistem: '5_hari' | '6_hari' = rawSistem.includes('6') ? '6_hari' : '5_hari';

    // Parse Jenis Hari
    const rawJenis = (parts[idxJenis] || '').toLowerCase();
    let jenisHari: 'biasa' | 'sabtu' | 'minggu' = 'biasa';
    if (rawJenis.includes('sabtu')) jenisHari = 'sabtu';
    else if (rawJenis.includes('minggu')) jenisHari = 'minggu';

    // Parse Libur
    const rawLibur = (parts[idxLibur] || '').toLowerCase();
    const libur = rawLibur === 'true' || rawLibur === 'ya' || rawLibur === '1';

    // Parse Jam Lembur
    const rawJam = (parts[idxJam] || '').replace(',', '.').replace(/[^0-9.]/g, '');
    const jamLembur = parseFloat(rawJam);
    if (isNaN(jamLembur) || jamLembur <= 0) {
      errors.push(`Baris ${lineNum}: Jam lembur '${parts[idxJam]}' tidak valid.`);
      continue;
    }

    // Parse Upah Sebulan
    const rawGaji = parts[idxGaji] ? parseFloat(parts[idxGaji].replace(/[^0-9]/g, '')) : 6000000;
    const upahSebulan = !isNaN(rawGaji) && rawGaji > 0 ? rawGaji : 6000000;

    const catatan = parts[idxCatatan] || '';
    const customId = parts[idxId] || `csv-${Date.now()}-${i}`;

    const calc = calculateOvertime({
      gajiPokok: upahSebulan,
      tunjanganTetap: 0,
      sistem,
      jenisHari,
      liburResmi: libur,
      jamLembur,
    });

    validEntries.push({
      id: customId,
      tanggal: rawTanggal,
      sistem,
      jenisHari,
      libur,
      jamLembur,
      upahSebulan: calc.upahSebulan,
      upahSejam: calc.upahSejam,
      totalLembur: calc.totalUpahLembur,
      catatan,
      dibuat: new Date().toISOString(),
      breakdown: calc.breakdown,
    });
  }

  return { validEntries, errors };
}
