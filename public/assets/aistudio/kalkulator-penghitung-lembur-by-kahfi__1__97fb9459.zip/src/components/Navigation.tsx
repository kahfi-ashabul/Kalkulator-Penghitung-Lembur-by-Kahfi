import React from 'react';
import { LayoutDashboard, Calculator, Banknote, History, Scale, Settings, Sparkles, Volume2, VolumeX, Sun, Moon } from 'lucide-react';

export type ScreenType = 'dashboard' | 'kalkulator' | 'gaji' | 'riwayat';

interface NavigationProps {
  currentScreen: ScreenType;
  onSelectScreen: (screen: ScreenType) => void;
  onOpenLegal: () => void;
  onOpenSettings: () => void;
  audioFeedback: boolean;
  onToggleAudio: () => void;
  theme: 'dark' | 'light';
  onToggleTheme: () => void;
  totalEntriesCount: number;
}

export const Navigation: React.FC<NavigationProps> = ({
  currentScreen,
  onSelectScreen,
  onOpenLegal,
  onOpenSettings,
  audioFeedback,
  onToggleAudio,
  theme,
  onToggleTheme,
  totalEntriesCount,
}) => {
  const navItems: Array<{ id: ScreenType; label: string; icon: React.ReactNode; badge?: number }> = [
    {
      id: 'dashboard',
      label: 'Dashboard',
      icon: <LayoutDashboard className="w-4 h-4" />,
    },
    {
      id: 'kalkulator',
      label: 'Hitung Lembur',
      icon: <Calculator className="w-4 h-4" />,
    },
    {
      id: 'gaji',
      label: 'Hitung Gaji',
      icon: <Banknote className="w-4 h-4" />,
    },
    {
      id: 'riwayat',
      label: 'Riwayat',
      icon: <History className="w-4 h-4" />,
      badge: totalEntriesCount,
    },
  ];

  return (
    <>
      {/* Top Deck Bar (Desktop & Tablet) */}
      <header className="sticky top-0 z-40 w-full bg-[#0A0A12]/90 backdrop-blur-xl border-b border-white/10 px-4 sm:px-8 py-3 transition-all">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
          {/* Brand Logo & Title */}
          <div
            onClick={() => onSelectScreen('dashboard')}
            className="flex items-center gap-3 cursor-pointer group select-none"
          >
            <div className="relative flex items-center justify-center w-9 h-9 rounded bg-[#161626] border border-[#00F0FF]/40 shadow-[0_0_12px_rgba(0,240,255,0.3)] group-hover:border-[#00F0FF] transition-all">
              <Sparkles className="w-5 h-5 text-[#00F0FF] group-hover:scale-110 transition-transform" />
              <div className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-[#39FF14] animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-white text-base tracking-tight font-heading">
                  KALKULATOR LEMBUR
                </span>
                <span className="text-[10px] font-mono font-bold px-1.5 py-0.5 rounded bg-gradient-to-r from-[#FF2BD6] to-[#7928CA] text-white">
                  by Kahfi
                </span>
              </div>
              <div className="flex items-center gap-2 text-[10px] text-[#7A7A99] font-mono">
                <span className="text-[#39FF14]">●</span>
                <span>PP 35/2021 COMPLIANT</span>
                <span className="hidden md:inline text-white/20">|</span>
                <span className="hidden md:inline text-[#b9cacb]">Labor Engine v1.1</span>
              </div>
            </div>
          </div>

          {/* Desktop Navigation Tabs */}
          <nav className="hidden md:flex items-center gap-1 bg-[#12121F] p-1 rounded-lg border border-white/10" role="tablist">
            {navItems.map((item) => {
              const isActive = currentScreen === item.id;
              return (
                <button
                  key={item.id}
                  role="tab"
                  aria-selected={isActive}
                  onClick={() => onSelectScreen(item.id)}
                  className={`relative flex items-center gap-2 px-4 py-2 rounded-md text-xs font-semibold transition-all select-none ${
                    isActive
                      ? 'bg-[#1A1A2E] text-[#00F0FF] shadow-[0_0_12px_rgba(0,240,255,0.25)] border border-[#00F0FF]/40'
                      : 'text-[#b9cacb] hover:text-white hover:bg-white/5'
                  }`}
                >
                  {item.icon}
                  <span>{item.label}</span>
                  {item.badge !== undefined && item.badge > 0 && (
                    <span className="px-1.5 py-0.2 rounded-full text-[10px] font-mono bg-[#00F0FF]/20 text-[#00F0FF] border border-[#00F0FF]/30">
                      {item.badge}
                    </span>
                  )}
                  {isActive && (
                    <div className="absolute -bottom-1 left-2 right-2 h-[2px] bg-gradient-to-r from-transparent via-[#00F0FF] to-transparent shadow-[0_0_8px_#00F0FF]" />
                  )}
                </button>
              );
            })}
          </nav>

          {/* Action Utilities */}
          <div className="flex items-center gap-2">
            {/* Theme Switcher Button */}
            <button
              onClick={onToggleTheme}
              className="p-2 rounded bg-[#161626] border border-white/10 hover:border-[#00F0FF] text-[#00F0FF] transition-all"
              title={theme === 'dark' ? 'Ganti ke Mode Terang' : 'Ganti ke Mode Gelap'}
            >
              {theme === 'dark' ? <Sun className="w-4 h-4 text-[#FFE600]" /> : <Moon className="w-4 h-4 text-[#00F0FF]" />}
            </button>

            <button
              onClick={onOpenLegal}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded bg-[#161626] border border-[#FFE600]/30 hover:border-[#FFE600] text-[#FFE600] text-xs font-mono transition-all shadow-[0_0_8px_rgba(255,230,0,0.15)]"
              title="Baca rujukan PP No. 35 Tahun 2021"
            >
              <Scale className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Dasar Hukum</span>
            </button>

            <button
              onClick={onToggleAudio}
              className={`p-2 rounded border text-xs transition-colors ${
                audioFeedback
                  ? 'bg-[#161626] border-[#00F0FF]/30 text-[#00F0FF] hover:border-[#00F0FF]'
                  : 'bg-[#161626] border-white/10 text-[#7A7A99] hover:text-white'
              }`}
              title={audioFeedback ? 'Matikan efek suara' : 'Nyalakan efek suara'}
            >
              {audioFeedback ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
            </button>

            <button
              onClick={onOpenSettings}
              className="p-2 rounded bg-[#161626] border border-white/10 hover:border-[#FF2BD6] text-[#b9cacb] hover:text-[#FF2BD6] transition-colors"
              title="Pengaturan profil dan preferensi"
            >
              <Settings className="w-4 h-4" />
            </button>
          </div>
        </div>
      </header>

      {/* Mobile Tactical Bottom Dock */}
      <nav
        className="md:hidden fixed bottom-0 left-0 right-0 z-50 bg-[#0A0A12]/95 backdrop-blur-2xl border-t border-white/10 px-2 py-1.5 pb-safe"
        role="tablist"
      >
        <div className="flex items-center justify-around">
          {navItems.map((item) => {
            const isActive = currentScreen === item.id;
            return (
              <button
                key={item.id}
                role="tab"
                aria-selected={isActive}
                onClick={() => onSelectScreen(item.id)}
                className={`relative flex flex-col items-center justify-center py-1.5 px-3 rounded-lg text-[10px] font-mono transition-all ${
                  isActive ? 'text-[#00F0FF]' : 'text-[#7A7A99] hover:text-white'
                }`}
              >
                {isActive && (
                  <span className="absolute -top-1 w-1.5 h-1.5 rounded-full bg-[#00F0FF] shadow-[0_0_6px_#00F0FF]" />
                )}
                <div className={`p-1 rounded ${isActive ? 'text-[#00F0FF]' : ''}`}>
                  {item.icon}
                </div>
                <span className="tracking-tight">{item.label}</span>
                {item.badge !== undefined && item.badge > 0 && (
                  <span className="absolute top-0.5 right-1 px-1 py-0.2 rounded-full text-[9px] bg-[#00F0FF] text-[#0A0A12] font-bold">
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </nav>
    </>
  );
};
