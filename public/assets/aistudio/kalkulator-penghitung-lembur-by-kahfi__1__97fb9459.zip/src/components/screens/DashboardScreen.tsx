import React, { useState, useMemo } from 'react';
import { 
  TrendingUp, 
  Clock, 
  Calendar, 
  DollarSign, 
  ChevronRight, 
  Plus, 
  ShieldCheck, 
  AlertTriangle, 
  Sparkles,
  Award,
  ArrowUpRight,
  ArrowDownRight,
  Share2,
  CalendarRange,
  HeartPulse,
  Briefcase,
  CheckCircle2,
  SlidersHorizontal
} from 'lucide-react';
import { OvertimeEntry, UserSettings, AttendanceRecord, AttendanceStatus } from '../../types/overtime';
import { formatRupiah, formatTanggal, formatJam, getCutoffDateRange } from '../../utils/calculations';
import { AdSlot } from '../AdSlot';
import { AttendanceModal } from '../modals/AttendanceModal';

interface DashboardScreenProps {
  entries: OvertimeEntry[];
  settings: UserSettings;
  attendanceMap: Record<string, AttendanceRecord>;
  onSaveAttendance: (record: AttendanceRecord) => void;
  onNavigateToCalculator: () => void;
  onNavigateToHistory: () => void;
  onNavigateToSalary: () => void;
  onOpenReceipt: (entry: OvertimeEntry) => void;
}

export const DashboardScreen: React.FC<DashboardScreenProps> = ({
  entries,
  settings,
  attendanceMap,
  onSaveAttendance,
  onNavigateToCalculator,
  onNavigateToHistory,
  onNavigateToSalary,
  onOpenReceipt,
}) => {
  // Period filter states
  const [cutoffMode, setCutoffMode] = useState<'kalender' | 'cut_off_20' | 'cut_off_25' | 'custom'>('kalender');
  const [selectedYear, setSelectedYear] = useState<number>(2026);
  const [selectedMonth, setSelectedMonth] = useState<number>(11); // 1-12, default Nov 2026
  const [customStart, setCustomStart] = useState<string>('2026-10-21');
  const [customEnd, setCustomEnd] = useState<string>('2026-11-20');

  // Attendance modal state
  const [attendanceModalOpen, setAttendanceModalOpen] = useState(false);
  const [modalDate, setModalDate] = useState('2026-11-05');

  // Hovered day for interactive telemetry inspector
  const [hoveredDay, setHoveredDay] = useState<{
    dateStr: string;
    jamReguler: number;
    jamLembur: number;
    nominal: number;
    status: AttendanceStatus;
    catatan?: string;
  } | null>(null);

  const months = [
    { value: 1, label: 'Januari' },
    { value: 2, label: 'Februari' },
    { value: 3, label: 'Maret' },
    { value: 4, label: 'April' },
    { value: 5, label: 'Mei' },
    { value: 6, label: 'Juni' },
    { value: 7, label: 'Juli' },
    { value: 8, label: 'Agustus' },
    { value: 9, label: 'September' },
    { value: 10, label: 'Oktober' },
    { value: 11, label: 'November' },
    { value: 12, label: 'Desember' },
  ];

  // Active Date Range
  const activeDateRange = useMemo(() => {
    return getCutoffDateRange(selectedYear, selectedMonth, cutoffMode, customStart, customEnd);
  }, [selectedYear, selectedMonth, cutoffMode, customStart, customEnd]);

  // Filter entries within active date range
  const rangeEntries = useMemo(() => {
    return entries
      .filter((e) => e.tanggal >= activeDateRange.startDate && e.tanggal <= activeDateRange.endDate)
      .sort((a, b) => new Date(b.tanggal).getTime() - new Date(a.tanggal).getTime());
  }, [entries, activeDateRange]);

  // Aggregated KPI Metrics
  const totalUpahLembur = useMemo(() => {
    return rangeEntries.reduce((acc, curr) => acc + curr.totalLembur, 0);
  }, [rangeEntries]);

  const totalJamLembur = useMemo(() => {
    return rangeEntries.reduce((acc, curr) => acc + curr.jamLembur, 0);
  }, [rangeEntries]);

  const jumlahHariLembur = rangeEntries.length;
  const rataRataJam = jumlahHariLembur > 0 ? totalJamLembur / jumlahHariLembur : 0;

  // Estimated base and take home
  const baseSalary = settings.defaultGajiPokok + settings.defaultTunjangan;
  const estimasiTotalGaji = baseSalary + totalUpahLembur;

  // Build daily timeline from startDate to endDate
  const timelineDays = useMemo(() => {
    const list: Array<{
      dateStr: string;
      dayNum: number;
      monthNum: number;
      dayOfWeek: number;
      jamReguler: number;
      jamLembur: number;
      nominal: number;
      status: AttendanceStatus;
      catatan?: string;
    }> = [];

    const start = new Date(activeDateRange.startDate);
    const end = new Date(activeDateRange.endDate);

    const pad = (n: number) => String(n).padStart(2, '0');

    for (let cur = new Date(start); cur <= end; cur.setDate(cur.getDate() + 1)) {
      const dateStr = `${cur.getFullYear()}-${pad(cur.getMonth() + 1)}-${pad(cur.getDate())}`;
      const dayOfWeek = cur.getDay(); // 0 is Sun, 6 is Sat

      // Get attendance record if exists
      const att = attendanceMap[dateStr];
      let status: AttendanceStatus = att ? att.status : (dayOfWeek === 0 || dayOfWeek === 6 ? 'libur_off' : 'masuk');
      let jamReguler = att ? att.jamKerjaReguler : (dayOfWeek === 0 || dayOfWeek === 6 ? 0 : (settings.defaultSistem === '6_hari' ? 7 : 8));
      let catatan = att?.catatan;

      // Get overtime entries for this day
      const dayEntries = rangeEntries.filter((e) => e.tanggal === dateStr);
      const dayJamLembur = dayEntries.reduce((acc, c) => acc + c.jamLembur, 0);
      const dayNominal = dayEntries.reduce((acc, c) => acc + c.totalLembur, 0);
      if (dayEntries.length > 0 && dayEntries[0].catatan) {
        catatan = dayEntries[0].catatan + (catatan ? ` • ${catatan}` : '');
      }

      list.push({
        dateStr,
        dayNum: cur.getDate(),
        monthNum: cur.getMonth() + 1,
        dayOfWeek,
        jamReguler,
        jamLembur: dayJamLembur,
        nominal: dayNominal,
        status,
        catatan,
      });
    }

    return list;
  }, [activeDateRange, attendanceMap, rangeEntries, settings.defaultSistem]);

  // Max total daily hours for chart height scaling - DYNAMIC to prevent clipping if > 16 hours
  const highestDayHours = Math.max(0, ...timelineDays.map((d) => d.jamReguler + d.jamLembur));
  const maxTotalHours = Math.max(16, Math.ceil((highestDayHours + 2) / 4) * 4);

  // Count attendance stats
  const totalHariMasuk = timelineDays.filter((d) => d.status === 'masuk').length;
  const totalHariSakit = timelineDays.filter((d) => d.status === 'sakit').length;
  const totalHariIzinCuti = timelineDays.filter((d) => d.status === 'izin' || d.status === 'cuti').length;

  // Akumulasi Lembur Hari Kerja Biasa Mingguan (Sesuai PP 35/2021 Pasal 26 ayat 2 - Libur resmi/akhir pekan DIKECUALIKAN)
  const regularWorkdayOvertimeHours = useMemo(() => {
    return rangeEntries
      .filter((e) => e.jenisHari === 'biasa' && !e.libur)
      .reduce((acc, curr) => acc + curr.jamLembur, 0);
  }, [rangeEntries]);

  // Evaluasi pelanggaran batas maksimal lembur hari biasa (> 4 jam/hari pada hari kerja biasa)
  const daysExceedingDailyLimit = useMemo(() => {
    return rangeEntries.filter((e) => e.jenisHari === 'biasa' && !e.libur && e.jamLembur > 4);
  }, [rangeEntries]);

  const handleDayBarClick = (dateStr: string) => {
    setModalDate(dateStr);
    setAttendanceModalOpen(true);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Top Banner & Cut-Off Period Selector */}
      <div className="p-4 sm:p-5 rounded-lg bg-[#12121F] border border-white/10 shadow-lg space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl sm:text-2xl font-extrabold text-white tracking-tight font-heading">
                Dashboard Ringkasan Lembur & Kehadiran
              </h1>
            </div>
            <p className="text-xs text-[#b9cacb] mt-0.5 font-sans">
              Pantau jam kerja masuk, absensi sakit/izin, serta akumulasi lembur harian dan bulanan.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                setModalDate(new Date().toISOString().slice(0, 10));
                setAttendanceModalOpen(true);
              }}
              className="px-3 py-2 rounded bg-[#1A1A2E] border border-[#39FF14]/40 hover:border-[#39FF14] text-[#39FF14] font-mono text-xs font-bold transition-all flex items-center gap-1.5"
            >
              <Briefcase className="w-3.5 h-3.5" />
              <span>Catat Absensi</span>
            </button>

            <button
              onClick={onNavigateToCalculator}
              className="px-3.5 py-2 rounded bg-gradient-to-r from-[#00F0FF] to-[#0082FB] text-[#0A0A12] font-bold text-xs font-mono hover:opacity-95 transition-all shadow-[0_0_12px_rgba(0,240,255,0.35)] flex items-center gap-1.5 shrink-0"
            >
              <Plus className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Hitung Lembur</span>
            </button>
          </div>
        </div>

        {/* Flexible Payroll Cut-off Toolbar */}
        <div className="p-3 rounded-lg bg-[#0A0A12] border border-white/10 flex flex-wrap items-center justify-between gap-3 text-xs font-mono">
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-[#b9cacb] flex items-center gap-1 text-[11px] font-bold uppercase">
              <CalendarRange className="w-3.5 h-3.5 text-[#00F0FF]" /> Periode Gaji:
            </span>

            {/* Mode Presets */}
            <div className="flex rounded bg-[#1A1A2E] p-0.5 border border-white/10">
              <button
                type="button"
                onClick={() => setCutoffMode('kalender')}
                className={`px-2.5 py-1 rounded text-xs transition-colors ${
                  cutoffMode === 'kalender' ? 'bg-[#00F0FF] text-[#0A0A12] font-bold' : 'text-[#7A7A99] hover:text-white'
                }`}
              >
                1 - Akhir Bulan
              </button>
              <button
                type="button"
                onClick={() => setCutoffMode('cut_off_20')}
                className={`px-2.5 py-1 rounded text-xs transition-colors ${
                  cutoffMode === 'cut_off_20' ? 'bg-[#00F0FF] text-[#0A0A12] font-bold' : 'text-[#7A7A99] hover:text-white'
                }`}
              >
                Cut-off 21 - 20
              </button>
              <button
                type="button"
                onClick={() => setCutoffMode('cut_off_25')}
                className={`px-2.5 py-1 rounded text-xs transition-colors ${
                  cutoffMode === 'cut_off_25' ? 'bg-[#00F0FF] text-[#0A0A12] font-bold' : 'text-[#7A7A99] hover:text-white'
                }`}
              >
                Cut-off 26 - 25
              </button>
              <button
                type="button"
                onClick={() => setCutoffMode('custom')}
                className={`px-2.5 py-1 rounded text-xs transition-colors ${
                  cutoffMode === 'custom' ? 'bg-[#FF2BD6] text-white font-bold' : 'text-[#7A7A99] hover:text-white'
                }`}
              >
                Rentang Kustom
              </button>
            </div>
          </div>

          {/* Month/Year or Custom Date Pickers */}
          {cutoffMode !== 'custom' ? (
            <div className="flex items-center gap-2">
              <select
                value={selectedMonth}
                onChange={(e) => setSelectedMonth(parseInt(e.target.value, 10))}
                className="px-2.5 py-1.5 rounded bg-[#1A1A2E] border border-white/10 text-white font-mono text-xs focus:outline-none focus:border-[#00F0FF]"
              >
                {months.map((m) => (
                  <option key={m.value} value={m.value}>
                    {m.label}
                  </option>
                ))}
              </select>
              <select
                value={selectedYear}
                onChange={(e) => setSelectedYear(parseInt(e.target.value, 10))}
                className="px-2.5 py-1.5 rounded bg-[#1A1A2E] border border-white/10 text-white font-mono text-xs focus:outline-none focus:border-[#00F0FF]"
              >
                <option value={2025}>2025</option>
                <option value={2026}>2026</option>
                <option value={2027}>2027</option>
              </select>
              <span className="text-[11px] text-[#00F0FF] font-bold hidden md:inline ml-1">
                ({activeDateRange.label})
              </span>
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <input
                type="date"
                value={customStart}
                onChange={(e) => setCustomStart(e.target.value)}
                className="px-2 py-1 rounded bg-[#1A1A2E] border border-white/10 text-white font-mono text-xs"
              />
              <span className="text-[#7A7A99]">s.d.</span>
              <input
                type="date"
                value={customEnd}
                onChange={(e) => setCustomEnd(e.target.value)}
                className="px-2 py-1 rounded bg-[#1A1A2E] border border-white/10 text-white font-mono text-xs"
              />
            </div>
          )}
        </div>
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Core Gross Overtime Metric */}
        <div className="p-5 rounded-lg bg-[#12121F] border border-[#39FF14]/40 shadow-[0_4px_24px_-2px_rgba(0,0,0,0.6)] backdrop-blur-md">
          <div className="flex items-center gap-2 text-xs font-mono text-[#b9cacb]">
            <DollarSign className="w-4 h-4 text-[#39FF14]" />
            <span className="font-bold text-white tracking-wide">TOTAL UPAH LEMBUR</span>
          </div>
          <div className="mt-3 text-2xl sm:text-3xl font-extrabold font-mono text-[#39FF14] tracking-tight drop-shadow-[0_0_16px_rgba(57,255,20,0.4)]">
            {formatRupiah(totalUpahLembur)}
          </div>
          <div className="mt-2 text-xs font-mono text-[#b9cacb]">
            Periode: {activeDateRange.label}
          </div>
        </div>

        {/* Total Overtime Hours & Attendance Count */}
        <div className="p-5 rounded-lg bg-[#12121F] border border-[#00F0FF]/30 shadow-lg backdrop-blur-md">
          <div className="flex items-center justify-between text-xs font-mono text-[#b9cacb]">
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-[#00F0FF]" />
              <span className="font-bold text-white tracking-wide">TOTAL JAM LEMBUR</span>
            </div>
            <span className="text-[10px] px-1.5 py-0.5 rounded bg-[#00F0FF]/15 text-[#00F0FF] font-bold border border-[#00F0FF]/30">
              {jumlahHariLembur} Hari Lembur
            </span>
          </div>
          <div className="mt-3 text-2xl sm:text-3xl font-extrabold font-mono text-white tracking-tight">
            {formatJam(totalJamLembur)}
          </div>
          <div className="mt-2 text-xs font-mono text-[#b9cacb] flex items-center justify-between">
            <span>Rata-rata: {rataRataJam.toFixed(1)} jam/hari</span>
            <span className="text-[#39FF14] flex items-center gap-1 text-[11px] font-bold">
              <ShieldCheck className="w-3.5 h-3.5" /> Terpantau
            </span>
          </div>
        </div>

        {/* Total Working Days & Sick Leave */}
        <div className="p-5 rounded-lg bg-[#12121F] border border-white/10 shadow-lg backdrop-blur-md">
          <div className="flex items-center justify-between text-xs font-mono text-[#b9cacb]">
            <div className="flex items-center gap-2">
              <Briefcase className="w-4 h-4 text-[#39FF14]" />
              <span className="font-bold text-white tracking-wide">REKAP ABSENSI</span>
            </div>
            <button
              onClick={() => {
                setModalDate(new Date().toISOString().slice(0, 10));
                setAttendanceModalOpen(true);
              }}
              className="text-[10px] text-[#00F0FF] hover:underline"
            >
              + Edit
            </button>
          </div>
          <div className="mt-3 text-2xl sm:text-3xl font-extrabold font-mono text-white tracking-tight">
            {totalHariMasuk} <span className="text-xs text-[#b9cacb] font-normal">Hari Masuk</span>
          </div>
          <div className="mt-2 text-xs font-mono flex items-center gap-3">
            <span className="text-[#F59E0B] font-bold">Sakit: {totalHariSakit} hr</span>
            <span className="text-[#EC4899] font-bold">Izin: {totalHariIzinCuti} hr</span>
          </div>
        </div>

        {/* Estimated Total Take Home Pay */}
        <div className="p-5 rounded-lg bg-[#12121F] border border-white/10 shadow-lg backdrop-blur-md">
          <div className="flex items-center justify-between text-xs font-mono text-[#b9cacb]">
            <div className="flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-[#39FF14]" />
              <span className="font-bold text-white tracking-wide">ESTIMASI GAJI PERIODE INI</span>
            </div>
            <button
              onClick={onNavigateToSalary}
              className="text-[10px] text-[#00F0FF] hover:underline flex items-center gap-0.5 font-mono font-bold"
            >
              Rincian <ChevronRight className="w-3 h-3" />
            </button>
          </div>
          <div className="mt-3 text-2xl sm:text-3xl font-extrabold font-mono text-white tracking-tight">
            {formatRupiah(estimasiTotalGaji)}
          </div>
          <div className="mt-2 text-xs font-mono text-[#b9cacb] flex items-center gap-1.5">
            <span>Gaji Pokok + Tunjangan + Lembur</span>
          </div>
        </div>
      </div>

      {/* Peringatan Batas Maksimal Lembur PP 35/2021 (Jika Aktif di Pengaturan) */}
      {settings.enableMaxOvertimeAlert !== false && (daysExceedingDailyLimit.length > 0 || regularWorkdayOvertimeHours > 18) && (
        <div className="p-4 rounded-lg bg-[#FFE600]/10 border border-[#FFE600]/40 text-[#FFE600] text-xs font-mono flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 shrink-0 text-[#FFE600] mt-0.5" />
          <div className="space-y-1">
            <div className="font-bold text-white text-sm flex items-center gap-2">
              <span>Peringatan Batas Maksimal Lembur (PP No. 35/2021 Pasal 26)</span>
            </div>
            {daysExceedingDailyLimit.length > 0 && (
              <p className="text-[#FFE600]">
                • Terdapat {daysExceedingDailyLimit.length} hari kerja biasa dengan lembur melebihi <strong>batas maksimal 4 jam/hari</strong> (yaitu: {daysExceedingDailyLimit.map(e => e.tanggal).join(', ')}).
              </p>
            )}
            {regularWorkdayOvertimeHours > 18 && (
              <p className="text-[#FFE600]">
                • Total lembur hari kerja biasa dalam periode ini mencapai <strong>{regularWorkdayOvertimeHours} jam</strong> (melebihi batas maksimal 18 jam/minggu untuk hari kerja biasa).
              </p>
            )}
            <p className="text-[#b9cacb] text-[11px] font-sans">
              Catatan: Lembur pada hari istirahat mingguan (Sabtu/Minggu) dan libur resmi tidak dibatasi 4 jam dan tidak dihitung ke kuota 18 jam/minggu sesuai Pasal 26 ayat (2).
            </p>
          </div>
        </div>
      )}

      {/* Interactive Stacked Bar Chart (Green Normal Work + Blue Overtime on Top) */}
      <div className="p-5 rounded-lg bg-[#12121F] border border-white/10 shadow-lg space-y-3">
        {/* Chart Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-white/10 pb-4">
          <div>
            <div className="flex flex-wrap items-center gap-2.5">
              <h2 className="text-base sm:text-lg font-bold text-white flex items-center gap-2 font-heading tracking-tight">
                <TrendingUp className="w-5 h-5 text-[#00F0FF]" />
                Grafik Kehadiran & Lembur Terhubung
              </h2>
              <span className="px-2.5 py-0.5 rounded bg-[#00F0FF]/15 text-[#00F0FF] text-xs font-mono font-bold border border-[#00F0FF]/40 shadow-[0_0_8px_rgba(0,240,255,0.2)]">
                {activeDateRange.label}
              </span>
            </div>
            <p className="text-xs text-[#b9cacb] font-mono mt-1">
              Batang <strong className="text-[#39FF14]">Hijau (Masuk Kerja)</strong> disambung Batang <strong className="text-[#00F0FF]">Biru (Jam Lembur)</strong> di atasnya.
            </p>
          </div>

          {/* Color Legends */}
          <div className="flex flex-wrap items-center gap-3 text-xs font-mono">
            <span className="flex items-center gap-1.5 text-xs text-[#dbfcff]">
              <span className="w-3 h-3 rounded-xs bg-[#10B981] shadow-[0_0_6px_#10B981]" /> Masuk Kerja (Hijau)
            </span>
            <span className="flex items-center gap-1.5 text-xs text-[#dbfcff]">
              <span className="w-3 h-3 rounded-xs bar-overtime-striped border border-[#00F0FF] shadow-[0_0_6px_#00F0FF]" /> Lembur (Cyan Arsir)
            </span>
            <span className="flex items-center gap-1.5 text-xs text-[#F59E0B]">
              <span className="w-3 h-3 rounded-xs bg-[#F59E0B]" /> Sakit (Oranye)
            </span>
            <span className="flex items-center gap-1.5 text-xs text-[#EC4899]">
              <span className="w-3 h-3 rounded-xs bg-[#EC4899]" /> Izin/Cuti (Pink)
            </span>
          </div>
        </div>

        {/* Pinned Telemetry Inspector (FIXED TOOLTIP: 100% VISIBLE, NEVER CUT OFF) */}
        <div className="p-3 rounded-md bg-[#0A0A12] border border-[#00F0FF]/30 text-xs font-mono min-h-[44px] flex items-center justify-between gap-3">
          {hoveredDay ? (
            <div className="flex flex-wrap items-center gap-3">
              <span className="px-2 py-0.5 rounded bg-[#00F0FF]/20 text-[#00F0FF] font-bold border border-[#00F0FF]/30">
                {formatTanggal(hoveredDay.dateStr)}
              </span>
              <span className="text-white">
                Status:{' '}
                <strong className={
                  hoveredDay.status === 'masuk' ? 'text-[#39FF14]' :
                  hoveredDay.status === 'sakit' ? 'text-[#F59E0B]' :
                  hoveredDay.status === 'izin' || hoveredDay.status === 'cuti' ? 'text-[#EC4899]' : 'text-[#7A7A99]'
                }>
                  {hoveredDay.status.toUpperCase()}
                </strong>
                {hoveredDay.jamReguler > 0 && ` (${hoveredDay.jamReguler} jam reguler)`}
              </span>
              {hoveredDay.jamLembur > 0 && (
                <span className="text-[#00F0FF] font-bold">
                  + Lembur: {hoveredDay.jamLembur} Jam ({formatRupiah(hoveredDay.nominal)})
                </span>
              )}
              {hoveredDay.catatan && (
                <span className="text-[#b9cacb] italic">"{hoveredDay.catatan}"</span>
              )}
            </div>
          ) : (
            <div className="text-[#b9cacb] flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-[#00F0FF] animate-pulse" />
              <span>Arahkan kursor atau klik batang kalender untuk melihat rincian & mengedit status hari.</span>
            </div>
          )}
          <span className="text-[10px] text-[#7A7A99] shrink-0">Klik batang untuk ubah status</span>
        </div>

        {/* Stacked Chart Area */}
        <div className="w-full overflow-x-auto pb-2">
          <div className="min-w-[760px]">
            {/* Chart Bars Canvas with Dynamic Y-Axis scale */}
            <div className="relative h-64 bg-[#0A0A12] border border-white/15 rounded-lg px-3 pt-6 pb-2">
              {/* Dynamic Y-Axis Gridlines (every 4 hours) */}
              {[4, 8, 12, 16, 20].filter(h => h < maxTotalHours).map((h) => (
                <div
                  key={h}
                  className={`absolute left-0 right-0 border-b border-dashed z-0 pointer-events-none ${
                    h === 8 ? 'border-[#39FF14]/40' : h === 12 ? 'border-[#00F0FF]/40' : 'border-white/10'
                  }`}
                  style={{ bottom: `${(h / maxTotalHours) * 82 + 8}%` }}
                >
                  <span
                    className={`absolute right-3 -top-3.5 text-[9px] font-mono font-bold px-1.5 py-0.2 rounded border ${
                      h === 8
                        ? 'text-[#39FF14] bg-[#0A0A12]/95 border-[#39FF14]/40'
                        : h === 12
                        ? 'text-[#00F0FF] bg-[#0A0A12]/95 border-[#00F0FF]/40'
                        : 'text-[#7A7A99] bg-[#0A0A12]/95 border-white/10'
                    }`}
                  >
                    {h} Jam {h === 8 ? '(Baku Normal)' : h === 12 ? '(Maks Hari Biasa)' : ''}
                  </span>
                </div>
              ))}

              {/* Bars Row */}
              <div className="relative z-10 h-full flex items-end gap-1 sm:gap-1.5">
                {timelineDays.map((item) => {
                  const totalJam = item.jamReguler + item.jamLembur;
                  const hasRegular = item.jamReguler > 0 && item.status === 'masuk';
                  const hasOvertime = item.jamLembur > 0;
                  const isSick = item.status === 'sakit';
                  const isLeave = item.status === 'izin' || item.status === 'cuti';

                  const regularHeight = (item.jamReguler / maxTotalHours) * 80;
                  const overtimeHeight = (item.jamLembur / maxTotalHours) * 80;

                  return (
                    <div
                      key={item.dateStr}
                      onClick={() => handleDayBarClick(item.dateStr)}
                      onMouseEnter={() => setHoveredDay(item)}
                      onMouseLeave={() => setHoveredDay(null)}
                      className="flex-1 flex flex-col items-center justify-end h-full cursor-pointer group"
                    >
                      {/* Numerical badge on top of bar */}
                      <div className="mb-1 text-[10px] font-mono font-bold text-center leading-tight">
                        {hasOvertime && hasRegular ? (
                          <span className="text-[#00F0FF] drop-shadow-[0_0_6px_#00F0FF]">
                            +{item.jamLembur}j
                          </span>
                        ) : hasOvertime ? (
                          <span className="text-[#00F0FF] drop-shadow-[0_0_6px_#00F0FF]">
                            {item.jamLembur}j
                          </span>
                        ) : hasRegular ? (
                          <span className="text-[#39FF14]">{item.jamReguler}j</span>
                        ) : isSick ? (
                          <span className="text-[#F59E0B]">Sakit</span>
                        ) : isLeave ? (
                          <span className="text-[#EC4899]">Izin</span>
                        ) : null}
                      </div>

                      {/* Stacked Bar Container */}
                      <div className="w-full flex flex-col justify-end items-center">
                        {/* Top Bar: Overtime (Single color #00F0FF with striped texture for colorblind accessibility) */}
                        {hasOvertime && (
                          <div
                            style={{ height: `${Math.max(10, overtimeHeight)}%` }}
                            className="w-full rounded-t bar-overtime-striped border border-[#00F0FF] shadow-[0_0_8px_rgba(0,240,255,0.4)] group-hover:brightness-125 transition-all relative flex items-center justify-center"
                            title={`Lembur: ${item.jamLembur} jam`}
                          >
                            <span className="text-[9px] font-mono font-bold text-[#0A0A12] bg-[#00F0FF]/90 px-0.5 rounded leading-none select-none">
                              +{item.jamLembur}
                            </span>
                          </div>
                        )}

                        {/* Bottom Bar: Regular Hours (Green #10B981) */}
                        {hasRegular && (
                          <div
                            style={{ height: `${Math.max(14, regularHeight)}%` }}
                            className={`w-full bg-[#10B981] border border-[#10B981] shadow-[0_0_6px_rgba(16,185,129,0.3)] group-hover:brightness-125 transition-all flex items-center justify-center ${
                              hasOvertime ? 'rounded-b' : 'rounded-t rounded-b'
                            }`}
                            title={`Masuk Kerja Normal: ${item.jamReguler} jam`}
                          >
                            <span className="text-[9px] font-mono font-bold text-[#0A0A12] select-none">
                              {item.jamReguler}j
                            </span>
                          </div>
                        )}

                        {/* Special Status: Sakit (Orange #F59E0B) */}
                        {isSick && (
                          <div
                            style={{ height: '35%' }}
                            className="w-full rounded-t bg-[#F59E0B] border border-[#F59E0B] shadow-[0_0_8px_rgba(245,158,11,0.4)] flex items-center justify-center text-[9px] font-bold text-[#0A0A12]"
                            title="Sakit"
                          >
                            S
                          </div>
                        )}

                        {/* Special Status: Izin/Cuti (Pink #EC4899) */}
                        {isLeave && (
                          <div
                            style={{ height: '35%' }}
                            className="w-full rounded-t bg-[#EC4899] border border-[#EC4899] shadow-[0_0_8px_rgba(236,72,153,0.4)] flex items-center justify-center text-[9px] font-bold text-white"
                            title="Izin / Cuti"
                          >
                            I
                          </div>
                        )}

                        {/* Off day baseline */}
                        {!hasRegular && !hasOvertime && !isSick && !isLeave && (
                          <div className="w-full h-1.5 bg-white/10 rounded" />
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* High-Contrast Date Numbers Row */}
            <div className="flex items-center gap-1 sm:gap-1.5 mt-2 px-3">
              {timelineDays.map((item) => {
                const hasActivity = item.jamLembur > 0 || item.jamReguler > 0 || item.status === 'sakit' || item.status === 'izin';
                const isWeekend = item.dayOfWeek === 0 || item.dayOfWeek === 6;

                return (
                  <div
                    key={item.dateStr}
                    onClick={() => handleDayBarClick(item.dateStr)}
                    className="flex-1 text-center cursor-pointer"
                  >
                    <span
                      className={`block text-[10px] sm:text-[11px] font-mono font-bold py-0.5 rounded transition-all ${
                        item.jamLembur > 0
                          ? 'bg-[#00F0FF] text-[#0A0A12] shadow-[0_0_6px_rgba(0,240,255,0.4)]'
                          : item.status === 'sakit'
                          ? 'bg-[#F59E0B] text-[#0A0A12]'
                          : item.status === 'izin' || item.status === 'cuti'
                          ? 'bg-[#EC4899] text-white'
                          : item.jamReguler > 0
                          ? 'text-[#39FF14]'
                          : isWeekend
                          ? 'text-[#7A7A99]'
                          : 'text-[#b9cacb]'
                      }`}
                      title={`${formatTanggal(item.dateStr)} (Klik untuk edit)`}
                    >
                      {item.dayNum}
                    </span>
                  </div>
                );
              })}
            </div>
            <div className="text-center text-[10px] font-mono text-[#b9cacb] mt-2">
              Klik pada tanggal untuk mengganti status kehadiran (Masuk, Sakit, Izin, Cuti, Libur)
            </div>
          </div>
        </div>
      </div>

      {/* Ruang Iklan / Sponsor Banner (Responsive 728x90 desktop, 320x50 mobile) */}
      <AdSlot
        type="leaderboard"
        sponsorName="Ruang Iklan"
        title="Slot Iklan Banner Ketenagakerjaan & HR"
        description="Tempat ideal untuk pasang iklan software payroll, lowongan kerja, atau pelatihan karir."
      />

      {/* Recent Entries & Statutory Check */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Entri Terbaru Dalam Periode Ini */}
        <div className="lg:col-span-2 p-5 rounded-lg bg-[#12121F] border border-white/10 shadow-lg">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                <Calendar className="w-4 h-4 text-[#00F0FF]" />
                Entri Lembur Periode Ini
              </h2>
              <p className="text-xs text-[#7A7A99] font-mono">
                {rangeEntries.length} entri lembur tercatat dalam rentang {activeDateRange.label}
              </p>
            </div>
            <button
              onClick={onNavigateToHistory}
              className="text-xs font-mono text-[#00F0FF] hover:underline flex items-center gap-1"
            >
              Buka Riwayat Lengkap ({entries.length}) <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {rangeEntries.length === 0 ? (
            <div className="p-8 text-center rounded border border-dashed border-white/10 bg-[#0A0A12]/40">
              <Sparkles className="w-8 h-8 text-[#00F0FF] mx-auto mb-2 opacity-60" />
              <div className="text-sm font-semibold text-white">Belum Ada Lembur di Periode Ini</div>
              <p className="text-xs text-[#7A7A99] mt-1 max-w-sm mx-auto">
                Gunakan tombol di bawah untuk menghitung lembur baru (baik aturan PP 35/2021 maupun tarif manual perusahaan).
              </p>
              <button
                onClick={onNavigateToCalculator}
                className="mt-4 px-4 py-2 rounded bg-[#00F0FF] text-[#0A0A12] font-bold text-xs font-mono hover:bg-[#7df4ff] transition-all"
              >
                + Hitung Lembur Sekarang
              </button>
            </div>
          ) : (
            <div className="divide-y divide-white/5 font-mono">
              {rangeEntries.slice(0, 5).map((entry) => (
                <div
                  key={entry.id}
                  className="py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-white/[0.02] transition-colors rounded px-2"
                >
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-white text-xs font-bold">
                        {formatTanggal(entry.tanggal)}
                      </span>
                      <span className={`text-[10px] px-1.5 py-0.2 rounded border uppercase ${
                        entry.jenisHari === 'minggu' 
                          ? 'border-[#FF2BD6]/40 text-[#FF2BD6] bg-[#FF2BD6]/10'
                          : entry.jenisHari === 'sabtu'
                          ? 'border-[#00F0FF]/40 text-[#00F0FF] bg-[#00F0FF]/10'
                          : 'border-white/20 text-[#b9cacb]'
                      }`}>
                        {entry.jenisHari} {entry.libur ? '(Libur)' : ''}
                      </span>
                      <span className="text-xs text-[#7A7A99]">
                        • {entry.jamLembur} jam
                      </span>
                      {entry.modeHitung && entry.modeHitung !== 'pp35' && (
                        <span className="text-[10px] px-1.5 py-0.2 rounded bg-[#FFE600]/15 text-[#FFE600] border border-[#FFE600]/30 font-bold">
                          TARIF PERUSAHAAN
                        </span>
                      )}
                    </div>
                    {entry.catatan && (
                      <div className="text-[11px] text-[#7A7A99] font-sans mt-0.5 truncate max-w-md">
                        {entry.catatan}
                      </div>
                    )}
                  </div>

                  <div className="flex items-center justify-between sm:justify-end gap-3">
                    <span className="text-sm font-bold text-[#39FF14]">
                      {formatRupiah(entry.totalLembur)}
                    </span>
                    <button
                      onClick={() => onOpenReceipt(entry)}
                      className="px-2.5 py-1 rounded bg-[#1A1A2E] border border-white/10 hover:border-[#00F0FF] text-[#00F0FF] text-xs flex items-center gap-1 transition-all"
                      title="Lihat Slip Gambar PNG"
                    >
                      <Share2 className="w-3 h-3" />
                      <span className="text-[10px]">Slip</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Right Col: Statutory PP 35/2021 Rules & Quick Audit */}
        <div className="p-5 rounded-lg bg-[#12121F] border border-white/10 shadow-lg flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 text-[#FFE600] font-bold text-sm mb-3">
              <ShieldCheck className="w-4 h-4" />
              <span>Audit Jam Lembur Periode</span>
            </div>

            <div className="space-y-3 text-xs font-mono">
              <div className="p-3 rounded bg-[#1A1A2E] border border-white/5">
                <div className="text-[#b9cacb] text-[11px]">Batas Lembur Mingguan</div>
                <div className="text-white font-bold mt-1 flex items-center justify-between">
                  <span>Maksimal 18 Jam / Minggu</span>
                  <span className="text-[#39FF14] text-[10px] font-normal">Pasal 26 (1)</span>
                </div>
                <div className="w-full bg-black/40 h-1.5 rounded-full mt-2 overflow-hidden">
                  <div 
                    className="bg-[#00F0FF] h-full rounded-full transition-all"
                    style={{ width: `${Math.min(100, (totalJamLembur / 72) * 100)}%` }}
                  />
                </div>
              </div>

              <div className="p-3 rounded bg-[#1A1A2E] border border-white/5">
                <div className="text-[#b9cacb] text-[11px]">Metode Perhitungan Fleksibel</div>
                <div className="text-white font-bold mt-1">
                  Mendukung PP 35 & Aturan Internal
                </div>
                <p className="text-[10px] text-[#7A7A99] font-sans mt-1">
                  Kalkulator kini menyediakan pilihan lembur PP 35/2021 dan tarif flat/nominal khusus perusahaan.
                </p>
              </div>

              <div className="p-3 rounded bg-[#1A1A2E] border border-white/5">
                <div className="text-[#b9cacb] text-[11px]">Status Kehadiran Periode Ini</div>
                <div className="text-white font-bold mt-1 flex items-center justify-between">
                  <span>{totalHariMasuk} Hadir • {totalHariSakit} Sakit • {totalHariIzinCuti} Izin</span>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-4 pt-4 border-t border-white/10 text-center">
            <button
              onClick={onNavigateToSalary}
              className="w-full py-2.5 rounded bg-[#1A1A2E] border border-white/15 hover:border-[#00F0FF] text-white text-xs font-mono font-bold transition-all flex items-center justify-center gap-1.5"
            >
              Simulasi Slip Gaji Periode Ini <ChevronRight className="w-3.5 h-3.5 text-[#00F0FF]" />
            </button>
          </div>
        </div>
      </div>

      {/* Attendance Modal */}
      <AttendanceModal
        isOpen={attendanceModalOpen}
        onClose={() => setAttendanceModalOpen(false)}
        selectedDate={modalDate}
        currentRecord={attendanceMap[modalDate]}
        sistem={settings.defaultSistem}
        onSaveRecord={onSaveAttendance}
      />
    </div>
  );
};
