import React, { useState, useRef } from 'react';
import { Upload, X, FileText, CheckCircle2, AlertCircle } from 'lucide-react';
import { OvertimeEntry } from '../../types/overtime';
import { parseImportJSON } from '../../utils/exportImport';
import { formatRupiah, formatTanggal } from '../../utils/calculations';

interface ImportModalProps {
  isOpen: boolean;
  onClose: () => void;
  onImportComplete: (newEntries: OvertimeEntry[], mode: 'merge' | 'replace') => void;
}

export const ImportModal: React.FC<ImportModalProps> = ({ isOpen, onClose, onImportComplete }) => {
  const [file, setFile] = useState<File | null>(null);
  const [validEntries, setValidEntries] = useState<OvertimeEntry[]>([]);
  const [errors, setErrors] = useState<string[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [importMode, setImportMode] = useState<'merge' | 'replace'>('merge');
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selected = e.target.files?.[0];
    if (!selected) return;
    setFile(selected);
    setIsProcessing(true);

    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      if (!text) {
        setErrors(['File kosong atau tidak dapat dibaca.']);
        setIsProcessing(false);
        return;
      }

      if (!selected.name.endsWith('.json')) {
        setErrors(['Format berkas tidak didukung. Mohon pilih berkas cadangan resmi berformat .JSON']);
        setIsProcessing(false);
        return;
      }

      const res = parseImportJSON(text);
      setValidEntries(res.validEntries);
      setErrors(res.errors);
      setIsProcessing(false);
    };

    reader.onerror = () => {
      setErrors(['Terjadi kesalahan membaca file lokal.']);
      setIsProcessing(false);
    };

    reader.readAsText(selected);
  };

  const handleCommit = () => {
    if (validEntries.length === 0) return;
    onImportComplete(validEntries, importMode);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-2xl max-h-[90vh] flex flex-col bg-[#12121F] border border-[#00F0FF]/30 rounded-lg shadow-2xl text-[#E4E1ED] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-[#00F0FF]/20 bg-[#0A0A12]">
          <div className="flex items-center gap-2">
            <Upload className="w-5 h-5 text-[#00F0FF]" />
            <div>
              <h3 className="font-bold text-white text-base">Pulihkan Cadangan Riwayat (JSON)</h3>
              <p className="text-xs text-[#b9cacb]">Mendukung berkas cadangan resmi berekstensi .JSON</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded text-[#7A7A99] hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 flex-1 overflow-y-auto space-y-4">
          {/* Upload Dropzone */}
          <div
            onClick={() => fileInputRef.current?.click()}
            className="border-2 border-dashed border-[#00F0FF]/30 hover:border-[#00F0FF] rounded-lg p-6 text-center cursor-pointer bg-[#0A0A12] transition-colors group"
          >
            <input
              ref={fileInputRef}
              type="file"
              accept=".json"
              onChange={handleFileChange}
              className="hidden"
            />
            <FileText className="w-10 h-10 mx-auto text-[#7A7A99] group-hover:text-[#00F0FF] mb-2 transition-colors" />
            <div className="text-sm font-semibold text-white">
              {file ? file.name : 'Pilih berkas cadangan (.JSON)'}
            </div>
            <div className="text-xs text-[#7A7A99] mt-1">
              Data diproses secara lokal 100% di browser tanpa diunggah ke server eksternal
            </div>
          </div>

          {/* Parse Results */}
          {file && (
            <div className="space-y-3">
              {/* Stats */}
              <div className="grid grid-cols-2 gap-3 text-xs font-mono">
                <div className="p-3 rounded bg-[#1A1A2E] border border-[#39FF14]/30 flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-[#39FF14]" />
                  <span>
                    <strong className="text-[#39FF14]">{validEntries.length}</strong> entri valid terdeteksi
                  </span>
                </div>
                <div className="p-3 rounded bg-[#1A1A2E] border border-[#ffb4ab]/30 flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 text-[#ffb4ab]" />
                  <span>
                    <strong className="text-[#ffb4ab]">{errors.length}</strong> baris peringatan/gagal
                  </span>
                </div>
              </div>

              {/* Error details if any */}
              {errors.length > 0 && (
                <div className="p-3 rounded bg-[#93000a]/20 border border-[#ffb4ab]/30 text-xs text-[#ffb4ab] max-h-32 overflow-y-auto space-y-1">
                  <div className="font-bold">Laporan Baris Tidak Valid:</div>
                  {errors.slice(0, 5).map((err, i) => (
                    <div key={i}>• {err}</div>
                  ))}
                  {errors.length > 5 && <div>...dan {errors.length - 5} kesalahan lainnya.</div>}
                </div>
              )}

              {/* Preview sample */}
              {validEntries.length > 0 && (
                <div className="border border-white/10 rounded overflow-hidden">
                  <div className="bg-[#1A1A2E] px-3 py-1.5 text-xs font-mono text-[#b9cacb] border-b border-white/10">
                    Pratinjau Data (3 entri pertama):
                  </div>
                  <div className="divide-y divide-white/5 text-xs font-mono">
                    {validEntries.slice(0, 3).map((item, idx) => (
                      <div key={idx} className="p-2.5 flex items-center justify-between bg-[#12121F]">
                        <div>
                          <div className="text-white font-semibold">{formatTanggal(item.tanggal)}</div>
                          <div className="text-[10px] text-[#7A7A99]">
                            {item.sistem === '5_hari' ? '5 Hari' : '6 Hari'} • {item.jenisHari.toUpperCase()} • {item.jamLembur} jam
                          </div>
                        </div>
                        <div className="text-[#39FF14] font-bold">
                          {formatRupiah(item.totalLembur)}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Mode choice */}
              {validEntries.length > 0 && (
                <div className="p-3 rounded bg-[#1A1A2E] border border-white/10">
                  <label className="text-xs font-mono text-[#b9cacb] block mb-2">
                    Metode Penyimpanan Data:
                  </label>
                  <div className="flex gap-4 text-xs">
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="radio"
                        name="importMode"
                        checked={importMode === 'merge'}
                        onChange={() => setImportMode('merge')}
                        className="accent-[#00F0FF]"
                      />
                      <span className="text-white">Gabung Data (Lewati ID duplikat)</span>
                    </label>
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="radio"
                        name="importMode"
                        checked={importMode === 'replace'}
                        onChange={() => setImportMode('replace')}
                        className="accent-[#FF2BD6]"
                      />
                      <span className="text-[#ffb4ab]">Ganti Seluruh Data Riwayat</span>
                    </label>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 bg-[#0A0A12] border-t border-white/10 flex justify-end gap-2">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded text-xs font-mono text-[#7A7A99] hover:text-white hover:bg-white/5 transition-all"
          >
            Batal
          </button>
          <button
            onClick={handleCommit}
            disabled={validEntries.length === 0 || isProcessing}
            className="px-5 py-2 rounded text-xs font-bold font-mono text-[#0A0A12] bg-[#00F0FF] hover:bg-[#7df4ff] disabled:opacity-40 disabled:cursor-not-allowed transition-all shadow-[0_0_12px_rgba(0,240,255,0.3)]"
          >
            Terapkan ({validEntries.length} Entri)
          </button>
        </div>
      </div>
    </div>
  );
};
