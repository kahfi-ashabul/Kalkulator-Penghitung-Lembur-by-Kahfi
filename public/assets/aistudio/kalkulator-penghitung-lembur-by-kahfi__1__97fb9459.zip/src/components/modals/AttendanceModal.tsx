import React, { useState, useEffect } from 'react';
import { X, Check, HeartPulse, FileText, Calendar, Clock, Briefcase, AlertCircle, Sparkles } from 'lucide-react';
import { AttendanceRecord, AttendanceStatus, SistemKerja } from '../../types/overtime';
import { formatTanggal } from '../../utils/calculations';

interface AttendanceModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedDate: string; // YYYY-MM-DD
  currentRecord?: AttendanceRecord;
  sistem: SistemKerja;
  onSaveRecord: (record: AttendanceRecord) => void;
}

export const AttendanceModal: React.FC<AttendanceModalProps> = ({
  isOpen,
  onClose,
  selectedDate,
  currentRecord,
  sistem,
  onSaveRecord,
}) => {
  const [tanggal, setTanggal] = useState(selectedDate);
  const [status, setStatus] = useState<AttendanceStatus>('masuk');
  const [jamKerjaReguler, setJamKerjaReguler] = useState<number>(sistem === '6_hari' ? 7 : 8);
  const [catatan, setCatatan] = useState('');

  useEffect(() => {
    if (selectedDate) {
      setTanggal(selectedDate);
    }
    if (currentRecord) {
      setStatus(currentRecord.status);
      setJamKerjaReguler(currentRecord.jamKerjaReguler);
      setCatatan(currentRecord.catatan || '');
    } else {
      const d = new Date(selectedDate);
      const day = d.getDay();
      if (day === 0 || day === 6) {
        setStatus('libur_off');
        setJamKerjaReguler(0);
        setCatatan(day === 0 ? 'Libur Hari Minggu' : 'Libur Hari Sabtu');
      } else {
        setStatus('masuk');
        setJamKerjaReguler(sistem === '6_hari' ? 7 : 8);
        setCatatan('Masuk Kerja Normal');
      }
    }
  }, [selectedDate, currentRecord, sistem]);

  if (!isOpen) return null;

  const handleStatusSelect = (s: AttendanceStatus) => {
    setStatus(s);
    if (s === 'masuk') {
      setJamKerjaReguler(sistem === '6_hari' ? 7 : 8);
    } else {
      setJamKerjaReguler(0);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSaveRecord({
      tanggal,
      status,
      jamKerjaReguler: status === 'masuk' ? jamKerjaReguler : 0,
      catatan,
    });
    onClose();
  };

  const statusOptions: Array<{ id: AttendanceStatus; label: string; icon: React.ReactNode; color: string; bg: string }> = [
    {
      id: 'masuk',
      label: 'Masuk Kerja',
      icon: <Briefcase className="w-4 h-4" />,
      color: '#39FF14',
      bg: 'bg-[#39FF14]/15 border-[#39FF14]/40 text-[#39FF14]',
    },
    {
      id: 'sakit',
      label: 'Sakit',
      icon: <HeartPulse className="w-4 h-4" />,
      color: '#F59E0B',
      bg: 'bg-[#F59E0B]/15 border-[#F59E0B]/40 text-[#F59E0B]',
    },
    {
      id: 'izin',
      label: 'Izin',
      icon: <FileText className="w-4 h-4" />,
      color: '#EC4899',
      bg: 'bg-[#EC4899]/15 border-[#EC4899]/40 text-[#EC4899]',
    },
    {
      id: 'cuti',
      label: 'Cuti Resmi',
      icon: <Calendar className="w-4 h-4" />,
      color: '#A855F7',
      bg: 'bg-[#A855F7]/15 border-[#A855F7]/40 text-[#A855F7]',
    },
    {
      id: 'libur_off',
      label: 'Libur / Off',
      icon: <Clock className="w-4 h-4" />,
      color: '#7A7A99',
      bg: 'bg-white/5 border-white/10 text-[#b9cacb]',
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-md bg-[#12121F] border border-[#00F0FF]/30 rounded-lg shadow-2xl text-[#E4E1ED] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-[#00F0FF]/20 bg-[#0A0A12]">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-[#00F0FF]" />
            <div>
              <h3 className="font-bold text-white text-base">Catat Status Kehadiran</h3>
              <p className="text-xs text-[#b9cacb] font-mono">{formatTanggal(tanggal)}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded text-[#7A7A99] hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-5 space-y-4 text-xs font-mono">
          <div>
            <label className="text-[#b9cacb] mb-1.5 flex items-center gap-1.5">
              <Calendar className="w-3.5 h-3.5 text-[#00F0FF]" />
              Tanggal
            </label>
            <input
              type="date"
              value={tanggal}
              onChange={(e) => setTanggal(e.target.value)}
              required
              className="w-full px-3 py-2 rounded bg-[#1A1A2E] border border-white/10 text-white focus:outline-none focus:border-[#00F0FF]"
            />
          </div>

          {/* Status Selection Cards */}
          <div>
            <label className="text-[#b9cacb] mb-2 block">
              Pilih Status Kehadiran Hari Ini:
            </label>
            <div className="grid grid-cols-2 gap-2">
              {statusOptions.map((opt) => {
                const isSelected = status === opt.id;
                return (
                  <button
                    key={opt.id}
                    type="button"
                    onClick={() => handleStatusSelect(opt.id)}
                    className={`p-2.5 rounded border text-left flex items-center gap-2 transition-all ${
                      isSelected
                        ? `${opt.bg} shadow-lg font-bold scale-[1.02]`
                        : 'bg-[#1A1A2E] border-white/10 text-[#7A7A99] hover:text-white hover:border-white/20'
                    }`}
                  >
                    {opt.icon}
                    <span>{opt.label}</span>
                    {isSelected && <Check className="w-3.5 h-3.5 ml-auto" />}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Regular working hours (if Masuk) */}
          {status === 'masuk' && (
            <div className="p-3 rounded bg-[#161626] border border-[#39FF14]/30 space-y-1.5">
              <label className="text-white font-bold flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-[#39FF14]" />
                Jam Kerja Normal (Batang Hijau):
              </label>
              <div className="flex items-center gap-3">
                <input
                  type="number"
                  min="1"
                  max="12"
                  value={jamKerjaReguler}
                  onChange={(e) => setJamKerjaReguler(parseFloat(e.target.value) || 0)}
                  className="w-24 px-3 py-1.5 rounded bg-[#0A0A12] border border-white/20 text-white font-bold text-sm focus:outline-none focus:border-[#39FF14]"
                />
                <span className="text-[11px] text-[#b9cacb]">
                  {sistem === '5_hari' ? 'Standar 8 jam (5 hari kerja)' : 'Standar 7 jam (6 hari kerja)'}
                </span>
              </div>
            </div>
          )}

          <div>
            <label className="text-[#b9cacb] mb-1 block">Catatan / Keterangan (Opsional)</label>
            <input
              type="text"
              value={catatan}
              onChange={(e) => setCatatan(e.target.value)}
              placeholder="Misal: Hadir shift 1, Sakit demam, dsb."
              className="w-full px-3 py-2 rounded bg-[#1A1A2E] border border-white/10 text-white focus:outline-none focus:border-[#00F0FF]"
            />
          </div>

          {/* Footer */}
          <div className="pt-3 border-t border-white/10 flex justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded text-[#7A7A99] hover:text-white"
            >
              Batal
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded font-bold bg-[#00F0FF] text-[#0A0A12] hover:bg-[#7df4ff] transition-all shadow-[0_0_12px_rgba(0,240,255,0.3)]"
            >
              Simpan Kehadiran
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
