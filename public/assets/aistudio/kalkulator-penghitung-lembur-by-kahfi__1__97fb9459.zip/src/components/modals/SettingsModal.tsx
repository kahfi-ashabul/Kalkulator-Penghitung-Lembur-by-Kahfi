import React, { useState } from 'react';
import { X, Settings, Save, Volume2, VolumeX, Building, User, DollarSign, Sun, Moon, BookOpen, AlertTriangle } from 'lucide-react';
import { UserSettings } from '../../types/overtime';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: UserSettings;
  onSaveSettings: (newSettings: UserSettings) => void;
  onOpenGuide: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onSaveSettings,
  onOpenGuide,
}) => {
  const [namaKaryawan, setNamaKaryawan] = useState(settings.namaKaryawan);
  const [namaPerusahaan, setNamaPerusahaan] = useState(settings.namaPerusahaan);
  const [defaultSistem, setDefaultSistem] = useState(settings.defaultSistem);
  const [defaultGajiPokok, setDefaultGajiPokok] = useState(settings.defaultGajiPokok);
  const [defaultTunjangan, setDefaultTunjangan] = useState(settings.defaultTunjangan);
  const [defaultUpahHarian, setDefaultUpahHarian] = useState(settings.defaultUpahHarian || 250000);
  const [audioFeedback, setAudioFeedback] = useState(settings.audioFeedback);
  const [theme, setTheme] = useState<'dark' | 'light'>(settings.theme || 'dark');
  const [showOnboardingGuide, setShowOnboardingGuide] = useState(settings.showOnboardingGuide ?? true);
  const [enableMaxOvertimeAlert, setEnableMaxOvertimeAlert] = useState(settings.enableMaxOvertimeAlert ?? true);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSaveSettings({
      ...settings,
      namaKaryawan,
      namaPerusahaan,
      defaultSistem,
      defaultGajiPokok,
      defaultTunjangan,
      defaultUpahHarian,
      audioFeedback,
      theme,
      showOnboardingGuide,
      enableMaxOvertimeAlert,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-[#12121F] border border-[#00F0FF]/30 rounded-lg shadow-2xl text-[#E4E1ED] overflow-hidden max-h-[92vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-[#00F0FF]/20 bg-[#0A0A12]">
          <div className="flex items-center gap-2">
            <Settings className="w-5 h-5 text-[#00F0FF]" />
            <h3 className="font-bold text-white text-base">Pengaturan Profil & Preferensi</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded text-[#7A7A99] hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-5 space-y-4 text-xs font-mono overflow-y-auto flex-1">
          {/* Theme Selector */}
          <div>
            <label className="text-[#b9cacb] mb-1.5 block">Tema Tampilan Aplikasi</label>
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => setTheme('dark')}
                className={`p-2.5 rounded-lg border flex items-center justify-center gap-2 transition-all ${
                  theme === 'dark'
                    ? 'bg-[#1A1A2E] border-[#00F0FF] text-[#00F0FF] shadow-[0_0_12px_rgba(0,240,255,0.2)] font-bold'
                    : 'bg-[#161626] border-white/10 text-[#7A7A99] hover:text-white'
                }`}
              >
                <Moon className="w-4 h-4" />
                <span>Mode Gelap (Cyber)</span>
              </button>
              <button
                type="button"
                onClick={() => setTheme('light')}
                className={`p-2.5 rounded-lg border flex items-center justify-center gap-2 transition-all ${
                  theme === 'light'
                    ? 'bg-white border-[#00F0FF] text-[#0A0A12] shadow-[0_0_12px_rgba(0,240,255,0.2)] font-bold'
                    : 'bg-[#161626] border-white/10 text-[#7A7A99] hover:text-white'
                }`}
              >
                <Sun className="w-4 h-4" />
                <span>Mode Terang</span>
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="text-[#b9cacb] mb-1 flex items-center gap-1.5">
                <User className="w-3.5 h-3.5 text-[#00F0FF]" />
                Nama Karyawan
              </label>
              <input
                type="text"
                value={namaKaryawan}
                onChange={(e) => setNamaKaryawan(e.target.value)}
                className="w-full px-3 py-2 rounded bg-[#1A1A2E] border border-white/10 text-white focus:outline-none focus:border-[#00F0FF]"
                placeholder="Contoh: M. Kahfi"
              />
            </div>

            <div>
              <label className="text-[#b9cacb] mb-1 flex items-center gap-1.5">
                <Building className="w-3.5 h-3.5 text-[#FF2BD6]" />
                Nama Perusahaan
              </label>
              <input
                type="text"
                value={namaPerusahaan}
                onChange={(e) => setNamaPerusahaan(e.target.value)}
                className="w-full px-3 py-2 rounded bg-[#1A1A2E] border border-white/10 text-white focus:outline-none focus:border-[#FF2BD6]"
                placeholder="Contoh: PT Teknologi Nusantara"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="text-[#b9cacb] mb-1 flex items-center gap-1.5">
                <DollarSign className="w-3.5 h-3.5 text-[#39FF14]" />
                Gaji Pokok (Rp)
              </label>
              <input
                type="number"
                step="500000"
                value={defaultGajiPokok}
                onChange={(e) => setDefaultGajiPokok(parseFloat(e.target.value) || 0)}
                className="w-full px-3 py-2 rounded bg-[#1A1A2E] border border-white/10 text-white focus:outline-none focus:border-[#39FF14]"
              />
            </div>

            <div>
              <label className="text-[#b9cacb] mb-1 block">Tunjangan Tetap (Rp)</label>
              <input
                type="number"
                step="100000"
                value={defaultTunjangan}
                onChange={(e) => setDefaultTunjangan(parseFloat(e.target.value) || 0)}
                className="w-full px-3 py-2 rounded bg-[#1A1A2E] border border-white/10 text-white focus:outline-none focus:border-[#39FF14]"
              />
            </div>

            <div>
              <label className="text-[#b9cacb] mb-1 block">Upah Harian Baku (Rp)</label>
              <input
                type="number"
                step="25000"
                value={defaultUpahHarian}
                onChange={(e) => setDefaultUpahHarian(parseFloat(e.target.value) || 0)}
                className="w-full px-3 py-2 rounded bg-[#1A1A2E] border border-white/10 text-white focus:outline-none focus:border-[#00F0FF]"
              />
            </div>
          </div>

          <div>
            <label className="text-[#b9cacb] mb-1 block">Sistem Kerja Bawaan</label>
            <select
              value={defaultSistem}
              onChange={(e) => setDefaultSistem(e.target.value as any)}
              className="w-full px-3 py-2 rounded bg-[#1A1A2E] border border-white/10 text-white focus:outline-none focus:border-[#00F0FF]"
            >
              <option value="5_hari">5 Hari Kerja (8 Jam/hari, 40 Jam/minggu)</option>
              <option value="6_hari">6 Hari Kerja (7 Jam/hari, 40 Jam/minggu)</option>
            </select>
          </div>

          {/* Preferences Toggles */}
          <div className="space-y-2 pt-1 border-t border-white/10">
            {/* Audio Toggle */}
            <label className="flex items-center justify-between p-2.5 rounded bg-[#1A1A2E] border border-white/10 cursor-pointer">
              <span className="flex items-center gap-2 text-white">
                {audioFeedback ? (
                  <Volume2 className="w-4 h-4 text-[#00F0FF]" />
                ) : (
                  <VolumeX className="w-4 h-4 text-[#7A7A99]" />
                )}
                Efek Suara Sintesis
              </span>
              <input
                type="checkbox"
                checked={audioFeedback}
                onChange={(e) => setAudioFeedback(e.target.checked)}
                className="accent-[#00F0FF] w-4 h-4"
              />
            </label>

            {/* Overtime Limit Alert Toggle */}
            <label className="flex items-center justify-between p-2.5 rounded bg-[#1A1A2E] border border-white/10 cursor-pointer">
              <span className="flex items-center gap-2 text-white">
                <AlertTriangle className="w-4 h-4 text-[#FFE600]" />
                Peringatan Batas Maksimal Lembur (4j hari biasa / 18j seminggu)
              </span>
              <input
                type="checkbox"
                checked={enableMaxOvertimeAlert}
                onChange={(e) => setEnableMaxOvertimeAlert(e.target.checked)}
                className="accent-[#00F0FF] w-4 h-4"
              />
            </label>

            {/* Onboarding Guide Toggle */}
            <label className="flex items-center justify-between p-2.5 rounded bg-[#1A1A2E] border border-white/10 cursor-pointer">
              <span className="flex items-center gap-2 text-white">
                <BookOpen className="w-4 h-4 text-[#00F0FF]" />
                Tampilkan Panduan Awal Setiap Mulai Aplikasi
              </span>
              <input
                type="checkbox"
                checked={showOnboardingGuide}
                onChange={(e) => setShowOnboardingGuide(e.target.checked)}
                className="accent-[#00F0FF] w-4 h-4"
              />
            </label>
          </div>

          {/* Manual open guide button */}
          <div className="pt-1">
            <button
              type="button"
              onClick={() => {
                onClose();
                onOpenGuide();
              }}
              className="w-full py-2 px-3 rounded bg-[#161626] border border-[#00F0FF]/30 text-[#00F0FF] hover:bg-[#00F0FF]/10 text-xs font-mono transition-colors flex items-center justify-center gap-1.5"
            >
              <BookOpen className="w-3.5 h-3.5" />
              <span>Buka Modal Panduan Penggunaan Sekarang</span>
            </button>
          </div>

          {/* Footer */}
          <div className="pt-3 border-t border-white/10 flex justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded text-xs text-[#7A7A99] hover:text-white"
            >
              Batal
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded text-xs font-bold bg-[#00F0FF] text-[#0A0A12] hover:bg-[#7df4ff] transition-all flex items-center gap-1.5 shadow-[0_0_12px_rgba(0,240,255,0.3)]"
            >
              <Save className="w-3.5 h-3.5" />
              Simpan Pengaturan
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
