/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Navigation, ScreenType } from './components/Navigation';
import { DashboardScreen } from './components/screens/DashboardScreen';
import { OvertimeCalculatorScreen } from './components/screens/OvertimeCalculatorScreen';
import { SalaryCalculatorScreen } from './components/screens/SalaryCalculatorScreen';
import { HistoryScreen } from './components/screens/HistoryScreen';
import { LegalInfoModal } from './components/modals/LegalInfoModal';
import { ReceiptModal } from './components/modals/ReceiptModal';
import { ImportModal } from './components/modals/ImportModal';
import { EditEntryModal } from './components/modals/EditEntryModal';
import { SettingsModal } from './components/modals/SettingsModal';
import { OnboardingModal } from './components/modals/OnboardingModal';
import { Footer } from './components/Footer';
import { 
  OvertimeEntry, 
  OvertimeCalculationResult, 
  UserSettings,
  AttendanceRecord 
} from './types/overtime';
import { 
  getStoredEntries, 
  saveStoredEntries, 
  addStoredEntry, 
  updateStoredEntry, 
  deleteStoredEntry, 
  clearAllStoredEntries, 
  getStoredSettings, 
  saveStoredSettings,
  getStoredAttendance,
  setAttendanceRecord 
} from './utils/storage';
import { playCyberClick, playCyberSuccess } from './utils/audio';

export default function App() {
  // Screen state - Initial Screen is Dashboard Ringkasan Lembur as requested
  const [currentScreen, setCurrentScreen] = useState<ScreenType>('dashboard');

  // Stored state
  const [entries, setEntries] = useState<OvertimeEntry[]>([]);
  const [settings, setSettings] = useState<UserSettings>(getStoredSettings());

  // Modals state
  const [isLegalOpen, setIsLegalOpen] = useState<boolean>(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState<boolean>(false);
  const [isImportOpen, setIsImportOpen] = useState<boolean>(false);
  const [isOnboardingOpen, setIsOnboardingOpen] = useState<boolean>(false);
  const [editingEntry, setEditingEntry] = useState<OvertimeEntry | null>(null);

  // Sync theme to <html> element
  useEffect(() => {
    const root = document.documentElement;
    if (settings.theme === 'light') {
      root.classList.remove('dark');
      root.classList.add('light');
    } else {
      root.classList.remove('light');
      root.classList.add('dark');
    }
  }, [settings.theme]);

  // Check onboarding guide on mount
  useEffect(() => {
    const loadedSettings = getStoredSettings();
    if (loadedSettings.showOnboardingGuide !== false) {
      setIsOnboardingOpen(true);
    }
  }, []);

  // Receipt Modal state
  const [isReceiptOpen, setIsReceiptOpen] = useState<boolean>(false);
  const [receiptData, setReceiptData] = useState<OvertimeCalculationResult | OvertimeEntry | null>(null);

  // Attendance State
  const [attendanceMap, setAttendanceMap] = useState<Record<string, AttendanceRecord>>({});

  // Initialize data on mount
  useEffect(() => {
    const loadedEntries = getStoredEntries();
    setEntries(loadedEntries);
    const loadedSettings = getStoredSettings();
    setSettings(loadedSettings);
    const loadedAttendance = getStoredAttendance();
    setAttendanceMap(loadedAttendance);
  }, []);

  const handleSaveAttendance = (record: AttendanceRecord) => {
    setAttendanceRecord(record);
    setAttendanceMap(getStoredAttendance());
    if (settings.audioFeedback) playCyberSuccess();
  };

  const handleSelectScreen = (screen: ScreenType) => {
    if (settings.audioFeedback) playCyberClick();
    setCurrentScreen(screen);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSaveEntry = (newEntry: OvertimeEntry) => {
    addStoredEntry(newEntry);
    setEntries(getStoredEntries());
  };

  const handleUpdateEntry = (updated: OvertimeEntry) => {
    updateStoredEntry(updated);
    setEntries(getStoredEntries());
    if (settings.audioFeedback) playCyberSuccess();
  };

  const handleDeleteEntry = (id: string) => {
    deleteStoredEntry(id);
    setEntries(getStoredEntries());
    if (settings.audioFeedback) playCyberClick();
  };

  const handleClearAllEntries = () => {
    clearAllStoredEntries();
    setEntries([]);
    if (settings.audioFeedback) playCyberClick();
  };

  const handleImportComplete = (imported: OvertimeEntry[], mode: 'merge' | 'replace') => {
    let finalEntries: OvertimeEntry[] = [];
    if (mode === 'replace') {
      finalEntries = imported;
    } else {
      const existingIds = new Set(entries.map((e) => e.id));
      const filteredNew = imported.filter((e) => !existingIds.has(e.id));
      finalEntries = [...filteredNew, ...entries];
    }
    saveStoredEntries(finalEntries);
    setEntries(finalEntries);
    if (settings.audioFeedback) playCyberSuccess();
  };

  const handleOpenReceiptFromCalc = (
    calcResult: OvertimeCalculationResult,
    date: string,
    note?: string
  ) => {
    if (settings.audioFeedback) playCyberClick();
    setReceiptData({
      ...calcResult,
      tanggal: date,
      catatan: note,
    } as any);
    setIsReceiptOpen(true);
  };

  const handleOpenReceiptFromEntry = (entry: OvertimeEntry) => {
    if (settings.audioFeedback) playCyberClick();
    setReceiptData(entry);
    setIsReceiptOpen(true);
  };

  const handleSaveSettings = (newSettings: UserSettings) => {
    saveStoredSettings(newSettings);
    setSettings(newSettings);
    if (settings.audioFeedback) playCyberSuccess();
  };

  const handleToggleAudio = () => {
    const updated = { ...settings, audioFeedback: !settings.audioFeedback };
    handleSaveSettings(updated);
  };

  return (
    <div className="min-h-screen flex flex-col cyber-canvas text-[#E4E1ED] pb-16 md:pb-0">
      {/* Pinned Navigation Deck */}
      <Navigation
        currentScreen={currentScreen}
        onSelectScreen={handleSelectScreen}
        onOpenLegal={() => {
          if (settings.audioFeedback) playCyberClick();
          setIsLegalOpen(true);
        }}
        onOpenSettings={() => {
          if (settings.audioFeedback) playCyberClick();
          setIsSettingsOpen(true);
        }}
        audioFeedback={settings.audioFeedback}
        onToggleAudio={handleToggleAudio}
        theme={settings.theme || 'dark'}
        onToggleTheme={() => {
          const next = settings.theme === 'light' ? 'dark' : 'light';
          handleSaveSettings({ ...settings, theme: next });
        }}
        totalEntriesCount={entries.length}
      />

      {/* Main Screen Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8">
        {currentScreen === 'dashboard' && (
          <DashboardScreen
            entries={entries}
            settings={settings}
            attendanceMap={attendanceMap}
            onSaveAttendance={handleSaveAttendance}
            onNavigateToCalculator={() => handleSelectScreen('kalkulator')}
            onNavigateToHistory={() => handleSelectScreen('riwayat')}
            onNavigateToSalary={() => handleSelectScreen('gaji')}
            onOpenReceipt={handleOpenReceiptFromEntry}
          />
        )}

        {currentScreen === 'kalkulator' && (
          <OvertimeCalculatorScreen
            settings={settings}
            onSaveEntry={handleSaveEntry}
            onOpenReceipt={handleOpenReceiptFromCalc}
            onOpenLegal={() => setIsLegalOpen(true)}
          />
        )}

        {currentScreen === 'gaji' && (
          <SalaryCalculatorScreen
            entries={entries}
            settings={settings}
          />
        )}

        {currentScreen === 'riwayat' && (
          <HistoryScreen
            entries={entries}
            settings={settings}
            onNavigateToCalculator={() => handleSelectScreen('kalkulator')}
            onEditEntry={(entry) => setEditingEntry(entry)}
            onDeleteEntry={handleDeleteEntry}
            onClearAllEntries={handleClearAllEntries}
            onOpenImportModal={() => setIsImportOpen(true)}
            onOpenReceipt={handleOpenReceiptFromEntry}
          />
        )}
      </main>

      {/* Footer without profile settings link */}
      <Footer
        onOpenLegal={() => setIsLegalOpen(true)}
      />

      {/* Onboarding Guide Modal */}
      <OnboardingModal
        isOpen={isOnboardingOpen}
        onClose={() => setIsOnboardingOpen(false)}
        onDontShowAgain={(dontShow) => {
          handleSaveSettings({
            ...settings,
            showOnboardingGuide: !dontShow,
          });
        }}
      />

      {/* Modals */}
      <LegalInfoModal
        isOpen={isLegalOpen}
        onClose={() => setIsLegalOpen(false)}
      />

      <ReceiptModal
        isOpen={isReceiptOpen}
        onClose={() => {
          setIsReceiptOpen(false);
          setReceiptData(null);
        }}
        data={receiptData}
        defaultNama={settings.namaKaryawan}
        defaultPerusahaan={settings.namaPerusahaan}
      />

      <ImportModal
        isOpen={isImportOpen}
        onClose={() => setIsImportOpen(false)}
        onImportComplete={handleImportComplete}
      />

      <EditEntryModal
        isOpen={Boolean(editingEntry)}
        onClose={() => setEditingEntry(null)}
        entry={editingEntry}
        onSave={handleUpdateEntry}
      />

      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        settings={settings}
        onSaveSettings={handleSaveSettings}
        onOpenGuide={() => setIsOnboardingOpen(true)}
      />
    </div>
  );
}
