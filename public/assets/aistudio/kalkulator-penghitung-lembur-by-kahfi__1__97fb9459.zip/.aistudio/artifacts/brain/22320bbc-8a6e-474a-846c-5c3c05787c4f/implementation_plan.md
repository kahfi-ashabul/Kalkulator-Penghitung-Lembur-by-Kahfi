# Rencana Implementasi (Revisi): Panduan Awal, Mode Insentif Mandiri, Dynamic Stacked Column Chart, & Validasi Presisi

Dokumen ini merupakan pembaruan rencana implementasi yang mengintegrasikan seluruh masukan dan koreksi krusial: penyesuaian logika peringatan batas maksimal lembur sesuai PP 35/2021, transparansi label mode insentif mandiri, skala sumbu Y chart yang dinamis dan ramah buta warna, pembatasan impor hanya file JSON, kondisi awal blank murni, serta pembersihan navigasi footer.

---

## User Review & Critical Decisions

> [!IMPORTANT]
> **Koreksi & Keputusan yang Diterapkan**:
> 1. **Aturan Batas Maksimal Lembur Presisi (PP 35/2021 Pasal 26)**:
>    - Batas maksimal **4 jam/hari** HANYA berlaku untuk lembur di **Hari Kerja Biasa**. Pada hari istirahat mingguan (Sabtu/Minggu) dan libur resmi, durasi lembur diperbolehkan hingga 11–12 jam kerja.
>    - Batas maksimal **18 jam/minggu** HANYA menghitung akumulasi lembur pada hari kerja biasa. Lembur pada hari libur resmi/istirahat mingguan **tidak diperhitungkan** ke dalam kuota 18 jam/minggu tersebut.
>    - Menggunakan istilah resmi **"Batas Maksimal"** (bukan "Batas Aman").
> 2. **Transparansi Label Mode Insentif Mandiri**:
>    - Diberikan label mencolok bertuliskan **"MODE INSENTIF MANDIRI (NON-PP 35/2021)"** pada ringkasan kalkulator, teks salinan clipboard, ekspor slip gambar PNG, dan ekspor riwayat agar HR/manajemen tidak salah paham.
> 3. **Stacked Column Chart Dinamis & Aksesibel**:
>    - Sumbu Y auto-scale dinamis: skala menyesuaikan jam harian tertinggi (`Math.max(12, highestDayHours + 2)`), sehingga jam 17+ tidak akan terpotong.
>    - Konsistensi satu warna lembur: **`#00F0FF` (Electric Cyan)** dengan pola garis halus (*stripe texture*) untuk diferensiasi visual.
>    - Setiap segmen kolom memiliki label angka/teks langsung (misal: `8j` pada hijau, `+4j` pada biru) sehingga ramah bagi pengguna buta warna tanpa mengandalkan warna semata.
> 4. **Impor Terbatas Hanya File JSON**:
>    - Menghapus opsi impor CSV. Modal impor dikhususkan 100% untuk membaca, memvalidasi struktur, dan merestorasi backup berkas `.json` aplikasi ini.
> 5. **Blank Slate Murni**:
>    - Memulai aplikasi dengan 0 entri riwayat dan empty state yang rapi memandu pengguna.
> 6. **Pembersihan Footer & Dukungan Dark/Light Theme**:
>    - Menghapus tautan "Pengaturan Profil" dari footer.
>    - Mengintegrasikan pemilih tema Terang/Gelap dan kontrol audio di navigasi utama dan Pengaturan.

---

## 1. Overview & Core Concept

Aplikasi menghadirkan kalkulator hak ketenagakerjaan berdaya presisi tinggi yang melayani dua skenario kerja:
1. **Standar Hukum Resmi**: PP No. 35 Tahun 2021 dengan pengali 1,5x, 2x, 3x, 4x, batas maksimal hari kerja biasa 4 jam/hari dan 18 jam/minggu.
2. **Fleksibilitas Kebijakan Perusahaan (Mode Insentif Mandiri)**: Pengguna dapat mengisi nominal upah harian sendiri dan menentukan nominal lembur/insentif (per jam atau per shift) sesuai kesepakatan internal kantor, dengan pelabelan transparan agar tidak disalahartikan sebagai ketentuan perundang-undangan.

---

## 2. User Experience & Visual Design

### Alur Tampilan & Interaksi
1. **Onboarding Guide Modal ("Cara Pemakaian")**:
   - Terbuka otomatis saat pertama kali dibuka jika `showOnboardingGuide = true`.
   - Menjelaskan 4 langkah: Pengaturan Komponen Upah -> Catat Kehadiran Harian -> Hitung Lembur (Resmi atau Insentif Mandiri) -> Slip & Riwayat.
   - Dilengkapi centang `[✓] Jangan ingatkan lagi di awal` (tersimpan di `localStorage` dan dapat diaktifkan kembali lewat Pengaturan).
2. **Dashboard dengan Dynamic Stacked Column Chart**:
   - Kolom bertumpuk:
     - **Bawah**: Jam Reguler Kerja Masuk (`#10B981` Emerald Hijau, teks `8j`).
     - **Atas**: Jam Lembur disambung di atasnya (`#00F0FF` Cyan dengan aksen garis arsir, teks `+Xj`).
     - **Sakit**: Kolom Oranye Amber (`#F59E0B`, teks `Sakit`).
     - **Izin / Cuti**: Kolom Pink Magenta (`#EC4899`, teks `Izin/Cuti`).
   - Sumbu Y dinamis dengan gridline interval 4 jam (0, 4, 8, 12, 16, 20... jam) proporsional terhadap nilai data maksimum.
   - Peringatan pintar batas maksimal:
     - Lembur hari kerja biasa > 4 jam: muncul peringatan *"Melebihi batas maksimal 4 jam lembur hari kerja biasa"*.
     - Lembur hari Sabtu/Minggu tidak diberi peringatan 4 jam karena regulasi mengizinkan hingga 11–12 jam.
     - Akumulasi lembur hari kerja biasa dalam seminggu > 18 jam: muncul peringatan *"Melebihi batas maksimal 18 jam lembur hari kerja per minggu"*.
3. **Format Impor Eksklusif JSON**:
   - Menggantikan tombol impor serbaguna dengan **Impor Berkas Cadangan JSON**.
   - Dilengkapi validasi skema, pratinjau jumlah entri yang akan dimasukkan, dan opsi *Gabungkan (Merge)* atau *Gantikan (Replace)*.

```
┌────────────────────────────────────────────────────────────────────────┐
│ HEADER: KALKULATOR LEMBUR by Kahfi ── [Dashboard|Hitung|Gaji|Riwayat]  │
│         [☀️/🌙 Tema] [🔊 Suara] [⚖️ PP 35] [⚙️ Pengaturan]              │
├────────────────────────────────────────────────────────────────────────┤
│ DASHBOARD: DYNAMIC STACKED COLUMN CHART (Ramah Buta Warna)             │
│ Jam                                                                    │
│ 16 │                                                                   │
│ 12 │                  ┌──────────┐ (+5j) [#00F0FF Arsir]              │
│  8 │ ┌──────────┐     ├──────────┤                                     │
│  4 │ │ 8j       │     │ 8j       │     ┌──────────┐ (Sakit)            │
│  0 └─┴──────────┴─────┴──────────┴─────┴──────────┴────────────────────│
│         01 Nov            02 Nov            03 Nov                     │
│      [Hadir Biasa]   [Hadir + Lembur]   [Izin Sakit]                   │
├────────────────────────────────────────────────────────────────────────┤
│ STATUS LEGAL: Mode Aktif = [RESMI PP 35/2021] / [INSENTIF MANDIRI]    │
└────────────────────────────────────────────────────────────────────────┘
```

---

## 3. Product Decisions & Technical Strategy

### Keputusan 1: Logika Validasi Batas Maksimal Lembur yang Taat Regulasi
- **Aturan Implementasi**:
  ```typescript
  // 1. Batas harian: HANYA untuk hari kerja biasa
  const isExceedDailyLimit = entry.jenisHari === 'biasa' && !entry.libur && entry.jamLembur > 4;

  // 2. Batas mingguan: HANYA akumulasi jam lembur hari kerja biasa dalam 1 minggu kalender
  // Lembur Sabtu/Minggu dan libur resmi DIKECUALIKAN dari batas 18 jam
  const weeklyRegularOvertimeHours = weeklyEntries
    .filter(e => e.jenisHari === 'biasa' && !e.libur)
    .reduce((acc, curr) => acc + curr.jamLembur, 0);
  const isExceedWeeklyLimit = weeklyRegularOvertimeHours > 18;
  ```
- **Labeling Teks**: Digunakan istilah resmi *"Melebihi Batas Maksimal (PP 35/2021)"*.

### Keputusan 2: Penandaan Jelas Mode Insentif Mandiri
- Setiap slip dan ekspor memuat watermark teks tegas:
  - `MODE INSENTIF MANDIRI (NON-PP 35/2021 - ATURAN INTERNAL PERUSAHAAN)`
  - Format perhitungan transparan: `Upah Harian (Rp X) + Insentif Lembur (Rp Y) = Total Hak Diterima (Rp Z)`.
  - Mencegah kesalahan persepsi bahwa nominal tersebut bersumber dari tarif dasar rumus pemerintah.

### Keputusan 3: Penataan Skala Sumbu Y dan Diferensiasi Visual Chart
- **Skala Dinamis**: Nilai maksimum grafik ditentukan dari `Math.max(12, Math.ceil((maxHoursInTimeline + 2) / 4) * 4)`. Jika seorang karyawan lembur hingga 17 jam, skala atas grafik otomatis menyesuaikan ke 20 jam sehingga bar tidak terpotong.
- **Diferensiasi Aksesibilitas**:
  - Warna lembur tunggal: `#00F0FF` (Cyan).
  - Ditambahkan pola tekstur CSS striped pada blok lembur (`repeating-linear-gradient`).
  - Label teks eksplisit durasi jam pada setiap balok.

### Keputusan 4: Impor Terbatas Hanya File JSON
- Komponen `ImportModal.tsx` dioptimalkan khusus untuk file ekstensi `.json`.
- Menghapus ketergantungan parser CSV yang rentan masalah pemisah titik koma/koma regional, memastikan keutuhan data hingga ke struktur breakdown hourly multiplier.

### Keputusan 5: Blank Slate Murni Tanpa Demo Seed
- Mengosongkan data awal di `src/utils/storage.ts`.
- Memberikan petunjuk *empty state* yang ramah di Dashboard dan Riwayat: *"Belum ada riwayat lembur. Catat kehadiran hari ini atau klik Tambah Lembur untuk memulai."*

---

## 4. Technical Architecture & Component Mapping

```
src/
├── types/overtime.ts         -> Mode perhitungan, batas maksimal, interface setting
├── utils/
│   ├── calculations.ts       -> Formula PP 35 & Insentif Mandiri, evaluasi batas maksimal
│   ├── storage.ts            -> Storage blank slate, flag onboarding guide, tema
│   └── exportImport.ts       -> Eksportir CSV/JSON & Parser JSON-only dengan validasi skema
├── components/
│   ├── Navigation.tsx        -> Header utama (Brand, Tabs, Theme Switcher ☀️/🌙, Audio, Setting)
│   ├── Footer.tsx            -> Bersih (hanya disclaimer legal & link JDIH resmi, tanpa setting)
│   ├── modals/
│   │   ├── OnboardingModal.tsx -> Modal panduan 4 langkah dengan centang "Jangan ingatkan lagi"
│   │   ├── SettingsModal.tsx   -> Profil, tema gelap/terang, audio, reset panduan, batas lembur
│   │   ├── ImportModal.tsx     -> Modal impor khusus JSON dengan verifikasi integritas
│   │   └── ReceiptModal.tsx    -> Slip gambar PNG dengan label status legal/insentif tegas
│   └── screens/
│       ├── DashboardScreen.tsx -> Dynamic Stacked Column Chart, telemetry bar, KPI kehadiran
│       ├── OvertimeCalculatorScreen.tsx -> Switcher PP 35 vs Insentif Mandiri, input harian
│       ├── SalaryCalculatorScreen.tsx   -> Hitung gaji bulanan/harian & rincian insentif
│       └── HistoryScreen.tsx            -> Riwayat, filter cut-off tanggal, ekspor CSV & backup JSON
```

---

## 5. Verification Plan

1. **Uji Validasi Batas Maksimal Lembur**:
   - Masukkan lembur 5 jam pada Hari Kerja Biasa -> sistem memunculkan peringatan *"Melebihi batas maksimal 4 jam lembur hari kerja biasa"*.
   - Masukkan lembur 8 jam pada Hari Minggu -> TIDAK memunculkan peringatan batas harian 4 jam.
   - Masukkan 5 entri hari biasa masing-masing 4 jam (total 20 jam) dalam 1 minggu -> muncul peringatan *"Total lembur hari kerja biasa minggu ini (20 jam) melebihi batas maksimal 18 jam"*.
   - Masukkan lembur hari Minggu 10 jam + hari biasa 10 jam -> TIDAK memicu peringatan 18 jam mingguan karena jam hari Minggu dikecualikan.
2. **Uji Transparansi Mode Insentif Mandiri**:
   - Pilih "Mode Insentif Mandiri", masukkan upah harian Rp 200.000 dan lembur 3 jam @ Rp 30.000.
   - Hasil Rp 290.000 tercetak dengan label tegas *"MODE INSENTIF MANDIRI (NON-PP 35/2021)"*.
   - Slip bukti PNG dan salinan clipboard menyertakan keterangan tersebut.
3. **Uji Dynamic Stacked Column Chart**:
   - Coba masukkan data ekstrem (misal 17 jam kerja total) -> sumbu Y otomatis meluas hingga 20 jam tanpa kolom terpotong.
   - Verifikasi warna tunggal lembur `#00F0FF` dengan pola arsir dan label angka jam langsung.
4. **Uji Impor Khusus JSON**:
   - Buka modal impor -> hanya menerima file `.json`.
   - File JSON yang diimpor tervalidasi dan muncul di daftar riwayat dengan benar.
5. **Uji Blank Slate & Onboarding**:
   - Buka aplikasi pertama kali -> data 0 entri, modal panduan muncul.
   - Centang "Jangan ingatkan lagi" -> tutup -> reload -> modal tidak muncul.
   - Buka menu Pengaturan -> aktifkan panduan -> modal dapat diakses kembali.
6. **Uji Mode Terang & Gelap**:
   - Toggle tombol tema -> tampilan beralih secara mulus antara mode terang dan gelap dengan kontras teks yang tetap tajam dan terbaca.
7. **Kompilasi & Lint**:
   - Jalankan `compile_applet` dan `lint_applet` bersamaan untuk memastikan 0 error TypeScript.
